import React, { useState, useEffect } from 'react';
import { IoMTDevice, IoMTReading } from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { iomtService } from '../../services/iomtService';
import { Badge } from '../common/Badge';
import {
  Activity,
  Heart,
  Droplet,
  Wind,
  Zap,
  Battery,
  AlertTriangle,
  Radio,
  ShieldCheck,
  CheckCircle2,
  RotateCcw,
} from 'lucide-react';

export const IoMTMonitoring: React.FC = () => {
  const [devices, setDevices] = useState<IoMTDevice[]>([]);
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [selectedAnomalyType, setSelectedAnomalyType] = useState<
    'TACHYCARDIA' | 'HYPERTENSIVE_CRISIS' | 'HYPERGLYCEMIA' | 'HYPOXIA'
  >('TACHYCARDIA');

  useEffect(() => {
    const update = () => {
      setDevices(storageService.getIoMTDevices());
    };

    update();
    const unsub = subscribeToStorage(update);

    // Stream live ticks every 3.5s
    const timer = setInterval(() => {
      if (isSimulating) {
        iomtService.tickReadings();
      }
    }, 3500);

    return () => {
      unsub();
      clearInterval(timer);
    };
  }, [isSimulating]);

  const abnormalDevices = devices.filter((d) => d.status === 'WARNING' || d.currentReading.isAbnormal);

  // Extract vitals from current devices
  const ecgDev = devices.find((d) => d.type === 'Smart ECG');
  const bpDev = devices.find((d) => d.type === 'Blood Pressure Monitor');
  const cgmDev = devices.find((d) => d.type === 'Continuous Glucose Monitor');
  const spO2Dev = devices.find((d) => d.type === 'Pulse Oximeter');

  const heartRateVal = ecgDev?.currentReading.heartRate || bpDev?.currentReading.heartRate || 72;
  const bpVal = bpDev?.currentReading.bloodPressure || '126/82 mmHg';
  const glucoseVal = cgmDev?.currentReading.glucose || 108;
  const spO2Val = spO2Dev?.currentReading.spO2 || 98;

  const handleInjectAnomaly = () => {
    let targetId = devices[0]?.id;
    if (selectedAnomalyType === 'TACHYCARDIA') {
      targetId = ecgDev?.id || devices[0]?.id;
    } else if (selectedAnomalyType === 'HYPERTENSIVE_CRISIS') {
      targetId = bpDev?.id || devices[0]?.id;
    } else if (selectedAnomalyType === 'HYPERGLYCEMIA') {
      targetId = cgmDev?.id || devices[0]?.id;
    } else if (selectedAnomalyType === 'HYPOXIA') {
      targetId = spO2Dev?.id || devices[0]?.id;
    }

    if (targetId) {
      iomtService.injectAnomaly(targetId, selectedAnomalyType);
    }
  };

  const handleRestoreAll = () => {
    devices.forEach((dev) => {
      iomtService.restoreNormal(dev.id);
    });
  };

  return (
    <div id="iomt-monitoring-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-cyan-400">
              IOMT EDGE TELEMETRY & HARDWARE DIDS
            </span>
            <Badge variant={abnormalDevices.length > 0 ? 'rose' : 'emerald'} dot>
              {abnormalDevices.length > 0
                ? `${abnormalDevices.length} Biometric Anomaly Detected`
                : 'All Devices Nominal & Secure'}
            </Badge>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">
            Internet of Medical Things (IoMT) Mesh
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Real-time biometric streams from cryptographic W3C DID-enabled patient edge sensors. Includes simulated statistical anomaly injection, zero trust payload signing, and automated blockchain audit anchors.
          </p>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-1.5 transition-all border ${
              isSimulating
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            <Radio className={`w-3.5 h-3.5 ${isSimulating ? 'text-emerald-400 animate-pulse' : ''}`} />
            <span>{isSimulating ? 'Live Telemetry ON' : 'Telemetry Paused'}</span>
          </button>

          <select
            value={selectedAnomalyType}
            onChange={(e) => setSelectedAnomalyType(e.target.value as any)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200 focus:outline-none"
          >
            <option value="TACHYCARDIA">Tachycardia (HR &gt; 150 BPM)</option>
            <option value="HYPERTENSIVE_CRISIS">Hypertensive Crisis (178/108)</option>
            <option value="HYPERGLYCEMIA">Hyperglycemia (245 mg/dL)</option>
            <option value="HYPOXIA">Hypoxia (SpO2 87%)</option>
          </select>

          <button
            id="btn-force-anomaly"
            onClick={handleInjectAnomaly}
            className="px-3.5 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-500/40 text-xs font-mono font-semibold flex items-center gap-1.5 shadow-sm"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span>Simulate Anomaly</span>
          </button>

          {abnormalDevices.length > 0 && (
            <button
              onClick={handleRestoreAll}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 text-xs font-mono flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restore Baseline</span>
            </button>
          )}
        </div>
      </div>

      {/* Live Vitals Grid (Heart Rate, BP, Glucose, SpO2) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Heart Rate */}
        <div
          className={`p-4 rounded-xl border transition-all ${
            heartRateVal > 120 || heartRateVal < 50
              ? 'bg-rose-950/60 border-rose-500 text-rose-200'
              : 'bg-slate-900/80 border-slate-800 text-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="flex items-center gap-1.5">
              <Heart
                className={`w-4 h-4 ${
                  heartRateVal > 120 || heartRateVal < 50
                    ? 'text-rose-400 animate-ping'
                    : 'text-rose-400'
                }`}
              />
              HEART RATE
            </span>
            <Badge variant={heartRateVal > 120 ? 'rose' : 'emerald'}>
              {heartRateVal > 120 ? 'TACHYCARDIA' : 'NORMAL'}
            </Badge>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black font-mono tracking-tight">{heartRateVal}</span>
            <span className="text-xs text-slate-400 font-mono">BPM</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-2 flex items-center justify-between border-t border-slate-800/80 pt-1.5">
            <span>Normal: 60 - 100</span>
            <span className="text-emerald-400">Smart ECG (Lead I)</span>
          </div>
        </div>

        {/* Blood Pressure */}
        <div
          className={`p-4 rounded-xl border transition-all ${
            bpDev?.currentReading.isAbnormal
              ? 'bg-amber-950/60 border-amber-500 text-amber-200'
              : 'bg-slate-900/80 border-slate-800 text-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-cyan-400" />
              BLOOD PRESSURE
            </span>
            <Badge variant={bpDev?.currentReading.isAbnormal ? 'amber' : 'emerald'}>
              {bpDev?.currentReading.isAbnormal ? 'HYPERTENSION' : 'NORMAL'}
            </Badge>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black font-mono tracking-tight">{bpVal}</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-2 flex items-center justify-between border-t border-slate-800/80 pt-1.5">
            <span>Target: &lt; 130/85</span>
            <span className="text-cyan-400">Omron BLE Mesh</span>
          </div>
        </div>

        {/* Blood Glucose */}
        <div
          className={`p-4 rounded-xl border transition-all ${
            glucoseVal > 180 || glucoseVal < 70
              ? 'bg-amber-950/60 border-amber-500 text-amber-200'
              : 'bg-slate-900/80 border-slate-800 text-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="flex items-center gap-1.5">
              <Droplet className="w-4 h-4 text-emerald-400" />
              BLOOD GLUCOSE
            </span>
            <Badge variant={glucoseVal > 180 ? 'amber' : 'emerald'}>
              {glucoseVal > 180 ? 'ELEVATED' : 'NOMINAL'}
            </Badge>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black font-mono tracking-tight">{glucoseVal}</span>
            <span className="text-xs text-slate-400 font-mono">mg/dL</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-2 flex items-center justify-between border-t border-slate-800/80 pt-1.5">
            <span>Target: 70 - 140</span>
            <span className="text-emerald-400">Dexcom CGM Mesh</span>
          </div>
        </div>

        {/* Blood Oxygen (SpO2) */}
        <div
          className={`p-4 rounded-xl border transition-all ${
            spO2Val < 92
              ? 'bg-rose-950/60 border-rose-500 text-rose-200'
              : 'bg-slate-900/80 border-slate-800 text-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="flex items-center gap-1.5">
              <Wind className="w-4 h-4 text-cyan-400" />
              BLOOD OXYGEN (SpO2)
            </span>
            <Badge variant={spO2Val < 92 ? 'rose' : 'emerald'}>
              {spO2Val < 92 ? 'HYPOXIA' : 'NORMAL'}
            </Badge>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black font-mono tracking-tight">{spO2Val}%</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-2 flex items-center justify-between border-t border-slate-800/80 pt-1.5">
            <span>Target: 95 - 100%</span>
            <span className="text-cyan-400">Nonin BLE Node</span>
          </div>
        </div>
      </div>

      {/* Connected IoMT Device Hardware Grid */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Connected IoMT Hardware Nodes & Device DIDs
          </h3>
          <span className="text-xs font-mono text-slate-500">
            {devices.length} Devices Authenticated
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {devices.map((device) => (
            <div
              key={device.id}
              className={`p-4 rounded-xl border font-mono space-y-3 transition-all ${
                device.status === 'WARNING' || device.currentReading.isAbnormal
                  ? 'bg-rose-950/40 border-rose-500/50'
                  : 'bg-slate-950 border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-100 font-sans">{device.name}</h4>
                  <span className="text-[10px] text-cyan-400 break-all">{device.did}</span>
                </div>
                <Badge
                  variant={
                    device.status === 'WARNING' || device.currentReading.isAbnormal
                      ? 'rose'
                      : 'emerald'
                  }
                  dot
                >
                  {device.status}
                </Badge>
              </div>

              {device.currentReading.isAbnormal && (
                <div className="p-2.5 rounded bg-rose-950/80 border border-rose-500/40 text-rose-300 text-[11px] flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{device.currentReading.anomalyDescription}</span>
                </div>
              )}

              <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400 pt-1 border-t border-slate-900">
                <div>
                  <span className="block text-slate-500">BATTERY</span>
                  <span className="text-slate-200 font-semibold">{device.battery}%</span>
                </div>
                <div>
                  <span className="block text-slate-500">FIRMWARE</span>
                  <span className="text-slate-200 font-semibold">{device.firmware}</span>
                </div>
                <div>
                  <span className="block text-slate-500">PATIENT</span>
                  <span className="text-emerald-400 font-semibold truncate block">
                    {device.patientName}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                <span>Institution: {device.institution}</span>
                <span>Last Update: {device.lastUpdate}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
