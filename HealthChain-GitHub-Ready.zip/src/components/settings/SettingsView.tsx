import React, { useState } from 'react';
import { User } from '../../types';
import { storageService } from '../../services/storageService';
import { Badge } from '../common/Badge';
import {
  Settings,
  User as UserIcon,
  Key,
  RotateCcw,
  Download,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Eye,
  EyeOff,
  Sparkles,
} from 'lucide-react';

interface SettingsViewProps {
  currentUser: User;
  onResetDemo: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentUser,
  onResetDemo,
}) => {
  const [showPrivateKey, setShowPrivateKey] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  // Simulated client-side key custody
  const simulatedPublicKey = `ed25519_pk_${currentUser.did.replace(/[^a-zA-Z0-9]/g, '')}_8f39a04b`;
  const simulatedPrivateKey = `ed25519_sk_${currentUser.id}_secret_client_custody_99214_vault`;

  const handleReset = () => {
    if (
      window.confirm(
        'Reset all simulated HealthChain data back to initial demonstration state? This will restore original EHR records, initial blocks, and reset consent grants.'
      )
    ) {
      storageService.resetAll();
      onResetDemo();
      setResetSuccess(true);
      setTimeout(() => setResetSuccess(false), 4000);
    }
  };

  const handleExportAuditLogs = () => {
    const data = {
      exportedAt: new Date().toISOString(),
      project:
        'Blockchain-Based Decentralized Identity and Dynamic Access Management System for Multi-Institutional Smart Healthcare and IoMT',
      ledger: storageService.getBlocks(),
      transactions: storageService.getTransactions(),
      securityEvents: storageService.getSecurityEvents(),
      permissions: storageService.getPermissions(),
      accessRequests: storageService.getAccessRequests(),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `healthchain-audit-export-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="settings-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-cyan-400">
              IDENTITY & SYSTEM CONTROLS
            </span>
            <Badge variant="cyan" dot>
              Local Client Security
            </Badge>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">Settings & Identity Custody</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Manage your cryptographic decentralized identity keys, export consortium blockchain audit logs, or restore the demonstration database to its initial clean presentation state.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            id="btn-export-audit-json"
            onClick={handleExportAuditLogs}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-mono font-medium border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Audit Logs (JSON)</span>
          </button>
        </div>
      </div>

      {resetSuccess && (
        <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs font-mono flex items-center gap-2.5">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>Demo state successfully restored to initial clean benchmark data!</span>
        </div>
      )}

      {/* User Profile & DID Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Profile Card */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <UserIcon className="w-4 h-4 text-emerald-400" /> Active Session Profile
            </h3>
            <Badge
              variant={
                currentUser.role === 'patient'
                  ? 'emerald'
                  : currentUser.role === 'doctor'
                  ? 'cyan'
                  : 'indigo'
              }
            >
              {currentUser.role.toUpperCase()}
            </Badge>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <span className="text-slate-500 block text-[10px]">NAME</span>
              <span className="text-slate-100 font-sans font-bold text-sm">
                {currentUser.name}
              </span>
            </div>

            <div>
              <span className="text-slate-500 block text-[10px]">EMAIL ADDRESS</span>
              <span className="text-slate-300">{currentUser.email}</span>
            </div>

            <div>
              <span className="text-slate-500 block text-[10px]">AFFILIATED INSTITUTION</span>
              <span className="text-cyan-300">{currentUser.institution}</span>
            </div>

            <div>
              <span className="text-slate-500 block text-[10px]">W3C DECENTRALIZED IDENTIFIER</span>
              <span className="text-emerald-300 font-bold">{currentUser.did}</span>
            </div>
          </div>
        </div>

        {/* Cryptographic Key Custody Card */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Key className="w-4 h-4 text-cyan-400" /> Self-Sovereign Key Vault (Ed25519)
            </h3>
            <Badge variant="emerald">Client-Side Custody</Badge>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <span className="text-slate-500 block text-[10px]">PUBLIC KEY (ANCHORED IN DID DOC)</span>
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800 text-slate-300 text-[11px] break-all">
                {simulatedPublicKey}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500 block text-[10px]">
                  PRIVATE KEY (LOCAL CUSTODY)
                </span>
                <button
                  onClick={() => setShowPrivateKey(!showPrivateKey)}
                  className="text-slate-400 hover:text-slate-200 text-[11px] flex items-center gap-1 font-sans"
                >
                  {showPrivateKey ? (
                    <>
                      <EyeOff className="w-3.5 h-3.5" /> Hide
                    </>
                  ) : (
                    <>
                      <Eye className="w-3.5 h-3.5" /> Reveal
                    </>
                  )}
                </button>
              </div>
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800 text-rose-300 text-[11px] break-all mt-1">
                {showPrivateKey ? simulatedPrivateKey : '••••••••••••••••••••••••••••••••••••••••••••'}
              </div>
              <p className="text-[10px] text-slate-500 mt-1 font-sans">
                Never shared with hospital servers or the blockchain. Used strictly to sign consent grants locally.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Demo Reset & Danger Zone */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <RotateCcw className="w-4 h-4 text-amber-400" /> Academic Demo Control & Benchmark Reset
          </h3>
          <span className="text-xs font-mono text-slate-500">Section 26 Compliance</span>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h4 className="text-xs font-bold text-slate-200 font-sans">Reset Application State</h4>
            <p className="text-xs text-slate-400 mt-0.5 max-w-xl font-sans">
              Clear all dynamically generated requests, newly minted DIDs, injected anomalies, and break-glass tokens. Restores the demo to the baseline state for another trial run or presentation.
            </p>
          </div>

          <button
            id="btn-reset-demo-state"
            onClick={handleReset}
            className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-2 transition-all shadow-md shrink-0"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Demo to Initial State</span>
          </button>
        </div>
      </div>
    </div>
  );
};
