import React from 'react';

interface BadgeProps {
  variant?: 'emerald' | 'cyan' | 'amber' | 'rose' | 'indigo' | 'slate' | 'violet';
  children: React.ReactNode;
  className?: string;
  dot?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  variant = 'emerald',
  children,
  className = '',
  dot = false,
}) => {
  const styles = {
    emerald: 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40',
    cyan: 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40',
    amber: 'bg-amber-950/80 text-amber-300 border-amber-500/40',
    rose: 'bg-rose-950/80 text-rose-300 border-rose-500/40',
    indigo: 'bg-indigo-950/80 text-indigo-300 border-indigo-500/40',
    slate: 'bg-slate-800 text-slate-300 border-slate-700',
    violet: 'bg-violet-950/80 text-violet-300 border-violet-500/40',
  };

  const dotColors = {
    emerald: 'bg-emerald-400',
    cyan: 'bg-cyan-400',
    amber: 'bg-amber-400 animate-pulse',
    rose: 'bg-rose-400 animate-ping',
    indigo: 'bg-indigo-400',
    slate: 'bg-slate-400',
    violet: 'bg-violet-400',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-medium border ${styles[variant]} ${className}`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dotColors[variant]}`} />}
      {children}
    </span>
  );
};
