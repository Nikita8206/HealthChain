import React, { useState, useEffect } from 'react';
import { User, AccessRequest, Permission, EHRRecordType } from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { authorizationService } from '../../services/authorizationService';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';
import {
  KeyRound,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldCheck,
  Send,
  Trash2,
  AlertTriangle,
  History,
  Lock,
} from 'lucide-react';

interface AccessControlProps {
  currentUser: User;
}

export const AccessControl: React.FC<AccessControlProps> = ({ currentUser }) => {
  const [requests, setRequests] = useState<AccessRequest[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [activeTab, setActiveTab] = useState<'pending' | 'active' | 'history'>('pending');

  // New Request Modal
  const [isNewReqOpen, setIsNewReqOpen] = useState(false);
  const [targetPatientDid, setTargetPatientDid] = useState('did:health:patient:001');
  const [targetPatientName, setTargetPatientName] = useState('Sarah Jenkins');
  const [doctorDid, setDoctorDid] = useState(
    currentUser.role === 'doctor' ? currentUser.did : 'did:health:doctor:001'
  );
  const [doctorName, setDoctorName] = useState(
    currentUser.role === 'doctor' ? currentUser.name : 'Dr. Marcus Vance'
  );
  const [requestedRecords, setRequestedRecords] = useState<EHRRecordType[]>([
    'Diagnosis',
    'Prescription',
  ]);
  const [purpose, setPurpose] = useState(
    'Metabolic assessment and outpatient prescription renewal'
  );
  const [duration, setDuration] = useState(24);

  useEffect(() => {
    const update = () => {
      setRequests(storageService.getAccessRequests());
      setPermissions(storageService.getPermissions());
    };
    update();
    return subscribeToStorage(update);
  }, []);

  const pendingRequests = requests.filter((r) => r.status === 'PENDING');
  const activePermissions = permissions.filter((p) => p.status === 'ACTIVE');
  const pastHistory = [
    ...permissions.filter((p) => p.status !== 'ACTIVE'),
    ...requests.filter((r) => r.status === 'REJECTED'),
  ];

  const handleApprove = (requestId: string) => {
    authorizationService.approveAccessRequest(requestId);
  };

  const handleReject = (requestId: string) => {
    authorizationService.rejectAccessRequest(requestId);
  };

  const handleRevoke = (permissionId: string) => {
    authorizationService.revokePermission(permissionId);
  };

  const handleCreateRequest = (e: React.FormEvent) => {
    e.preventDefault();
    authorizationService.createAccessRequest({
      doctorDid,
      doctorName,
      patientDid: targetPatientDid,
      patientName: targetPatientName,
      institution: 'CityCare Hospital',
      requestedRecords,
      purpose,
      accessDurationHours: Number(duration),
    });
    setIsNewReqOpen(false);
  };

  const allRecordTypes: EHRRecordType[] = [
    'Diagnosis',
    'Prescription',
    'Laboratory Report',
    'Allergy',
    'Treatment History',
    'Medical Notes',
    'Genetic Data',
  ];

  const toggleRecord = (t: EHRRecordType) => {
    if (requestedRecords.includes(t)) {
      setRequestedRecords(requestedRecords.filter((x) => x !== t));
    } else {
      setRequestedRecords([...requestedRecords, t]);
    }
  };

  return (
    <div id="access-control-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-emerald-400">
              DYNAMIC ACCESS MANAGEMENT
            </span>
            <Badge variant="emerald" dot>
              Patient-Controlled Consent
            </Badge>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">
            Access Request & Consent Governance
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Fine-grained, time-bounded, context-aware authorization. When a doctor submits a request, it enters PENDING state until the patient explicitly signs an approval on the blockchain ledger.
          </p>
        </div>

        <button
          id="btn-create-access-request-main"
          onClick={() => setIsNewReqOpen(true)}
          className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-semibold flex items-center gap-2 transition-all shadow-md shrink-0"
        >
          <Send className="w-4 h-4" />
          <span>New Access Request</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          id="tab-pending-requests"
          onClick={() => setActiveTab('pending')}
          className={`px-4 py-2 rounded-lg text-xs font-mono font-medium flex items-center gap-2 transition-all ${
            activeTab === 'pending'
              ? 'bg-slate-800 text-amber-300 border border-amber-500/40'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Clock className="w-4 h-4 text-amber-400" />
          <span>Pending Requests</span>
          <span className="px-1.5 py-0.2 text-[10px] rounded bg-slate-900 text-amber-300">
            {pendingRequests.length}
          </span>
        </button>

        <button
          id="tab-active-permissions"
          onClick={() => setActiveTab('active')}
          className={`px-4 py-2 rounded-lg text-xs font-mono font-medium flex items-center gap-2 transition-all ${
            activeTab === 'active'
              ? 'bg-slate-800 text-emerald-300 border border-emerald-500/40'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Active Grants & Permissions</span>
          <span className="px-1.5 py-0.2 text-[10px] rounded bg-slate-900 text-emerald-300">
            {activePermissions.length}
          </span>
        </button>

        <button
          id="tab-consent-history"
          onClick={() => setActiveTab('history')}
          className={`px-4 py-2 rounded-lg text-xs font-mono font-medium flex items-center gap-2 transition-all ${
            activeTab === 'history'
              ? 'bg-slate-800 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <History className="w-4 h-4 text-cyan-400" />
          <span>Revocation & History</span>
        </button>
      </div>

      {/* TAB 1: PENDING REQUESTS */}
      {activeTab === 'pending' && (
        <div className="space-y-4">
          {pendingRequests.length === 0 ? (
            <div className="p-12 text-center rounded-xl bg-slate-900/60 border border-slate-800 text-slate-400 text-xs font-mono">
              No pending access requests. Click &quot;New Access Request&quot; to test the doctor submission flow.
            </div>
          ) : (
            pendingRequests.map((req) => (
              <div
                key={req.id}
                id={`access-req-card-${req.id}`}
                className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 shadow-md space-y-3"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-100 text-sm">{req.doctorName}</span>
                    <Badge variant="cyan">{req.institution}</Badge>
                    <span className="text-[11px] font-mono text-cyan-400">DID: {req.doctorDid}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono">
                    <Badge variant="amber" dot>
                      STATUS: PENDING PATIENT CONSENT
                    </Badge>
                    <span className="text-slate-400 text-[10px]">
                      {new Date(req.requestTimestamp).toLocaleTimeString()}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block text-[11px]">Patient:</span>
                    <span className="text-slate-200 font-semibold">{req.patientName}</span>
                    <span className="text-slate-400 block text-[10px] mt-0.5">{req.patientDid}</span>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block text-[11px]">Requested Record Types:</span>
                    <span className="text-emerald-300 font-semibold">
                      {req.requestedRecords.join(', ')}
                    </span>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block text-[11px]">Duration & Context:</span>
                    <span className="text-slate-200 font-semibold">
                      {req.accessDurationHours} Hours Time-Lock
                    </span>
                    <span className="text-slate-400 block text-[10px] mt-0.5 truncate">
                      Purpose: &quot;{req.purpose}&quot;
                    </span>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <div className="text-[11px] font-mono text-slate-400">
                    Ledger Tx Hash:{' '}
                    <span className="text-slate-300">
                      {req.transactionHash ? `${req.transactionHash.slice(0, 16)}...` : 'Pending block seal'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <button
                      id={`btn-approve-access-${req.id}`}
                      onClick={() => handleApprove(req.id)}
                      className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors"
                    >
                      <CheckCircle2 className="w-4 h-4" /> Approve Access
                    </button>
                    <button
                      id={`btn-reject-access-${req.id}`}
                      onClick={() => handleReject(req.id)}
                      className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/80 hover:text-rose-300 text-slate-300 text-xs font-medium flex items-center gap-1.5 border border-slate-700 transition-colors"
                    >
                      <XCircle className="w-4 h-4" /> Reject
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 2: ACTIVE PERMISSIONS */}
      {activeTab === 'active' && (
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Doctor / DID</th>
                  <th className="py-2.5 px-3">Institution</th>
                  <th className="py-2.5 px-3">Approved Scope</th>
                  <th className="py-2.5 px-3">Granted Date</th>
                  <th className="py-2.5 px-3">Expiry Date</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {activePermissions.map((perm) => (
                  <tr key={perm.id} id={`active-perm-${perm.id}`} className="hover:bg-slate-800/30">
                    <td className="py-3 px-3">
                      <div className="font-sans font-medium text-slate-100">{perm.doctorName}</div>
                      <div className="text-[10px] text-slate-400">{perm.doctorDid}</div>
                    </td>
                    <td className="py-3 px-3 text-slate-400">{perm.institution}</td>
                    <td className="py-3 px-3">
                      <span className="text-emerald-300 font-semibold">
                        {perm.recordTypes.join(', ')}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-400 text-[11px]">
                      {new Date(perm.grantedDate).toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-slate-400 text-[11px]">
                      {new Date(perm.expiryDate).toLocaleString()}
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        ACTIVE
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        id={`btn-revoke-${perm.id}`}
                        onClick={() => handleRevoke(perm.id)}
                        className="px-3 py-1 rounded bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-500/40 text-xs font-semibold transition-colors"
                      >
                        Revoke Access
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: REVOCATION & HISTORY */}
      {activeTab === 'history' && (
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Doctor</th>
                  <th className="py-2.5 px-3">Patient</th>
                  <th className="py-2.5 px-3">Scope / Event</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Tx Hash</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {pastHistory.map((item, idx) => {
                  const isPerm = 'recordTypes' in item;
                  const status = item.status;
                  return (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-3 text-slate-200">{item.doctorName}</td>
                      <td className="py-2.5 px-3 text-slate-400">{item.patientName}</td>
                      <td className="py-2.5 px-3 text-slate-300">
                        {isPerm ? (item as Permission).recordTypes.join(', ') : 'Access Request'}
                      </td>
                      <td className="py-2.5 px-3">
                        <Badge variant={status === 'REVOKED' || status === 'REJECTED' ? 'rose' : 'slate'}>
                          {status}
                        </Badge>
                      </td>
                      <td className="py-2.5 px-3 text-cyan-300 text-[10px]">
                        {item.transactionHash ? `${item.transactionHash.slice(0, 14)}...` : 'N/A'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* NEW ACCESS REQUEST MODAL */}
      <Modal
        isOpen={isNewReqOpen}
        onClose={() => setIsNewReqOpen(false)}
        title="Create Access Request"
        subtitle="Submit dynamic authorization consent request"
        maxWidth="lg"
      >
        <form onSubmit={handleCreateRequest} className="space-y-4 text-xs font-sans">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Requesting Physician</label>
            <input
              type="text"
              value={doctorName}
              onChange={(e) => setDoctorName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono text-xs"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Doctor DID</label>
            <input
              type="text"
              value={doctorDid}
              onChange={(e) => setDoctorDid(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-cyan-300 font-mono text-xs"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Target Patient DID</label>
            <input
              type="text"
              value={targetPatientDid}
              onChange={(e) => setTargetPatientDid(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-cyan-300 font-mono text-xs"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Select Record Scope (Checkboxes)
            </label>
            <div className="grid grid-cols-2 gap-2 font-mono">
              {allRecordTypes.map((t) => (
                <button
                  type="button"
                  key={t}
                  onClick={() => toggleRecord(t)}
                  className={`p-2 rounded-lg border text-left flex items-center justify-between text-xs transition-all ${
                    requestedRecords.includes(t)
                      ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-200'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <span>{t}</span>
                  {requestedRecords.includes(t) && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Clinical Purpose</label>
            <input
              type="text"
              required
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs font-mono"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Time-Locked Duration (Hours)
            </label>
            <select
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs font-mono"
            >
              <option value={1}>1 Hour</option>
              <option value={4}>4 Hours</option>
              <option value={24}>24 Hours</option>
              <option value={48}>48 Hours</option>
            </select>
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsNewReqOpen(false)}
              className="px-4 py-1.5 rounded-lg bg-slate-800 text-slate-300 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={requestedRecords.length === 0}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold flex items-center gap-1.5"
            >
              <Send className="w-4 h-4" /> Submit Request
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
