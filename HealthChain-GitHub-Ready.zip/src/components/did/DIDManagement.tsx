import React, { useState, useEffect } from 'react';
import { DIDDocument, DIDIdentity } from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { didService } from '../../services/didService';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';
import {
  Fingerprint,
  ShieldCheck,
  PlusCircle,
  CheckCircle2,
  FileCode,
  Copy,
  Check,
  Key,
  Globe,
  Lock,
} from 'lucide-react';

export const DIDManagement: React.FC = () => {
  const [dids, setDids] = useState<DIDIdentity[]>([]);
  const [selectedDoc, setSelectedDoc] = useState<DIDDocument | null>(null);
  const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  // Form for DID Generation
  const [newType, setNewType] = useState<'Patient' | 'Doctor' | 'Administrator' | 'IoMT_Device'>('Patient');
  const [newName, setNewName] = useState('');
  const [newInstitution, setNewInstitution] = useState('CityCare Hospital');

  useEffect(() => {
    const update = () => {
      setDids(storageService.getDIDs());
    };
    update();
    return subscribeToStorage(update);
  }, []);

  const handleVerifyDID = (didString: string) => {
    didService.verifyDID(didString);
  };

  const handleViewDoc = (identity: DIDIdentity) => {
    const doc = didService.buildDIDDocument(identity);
    setSelectedDoc(doc);
  };

  const handleGenerateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName) return;
    didService.generateDID(newType, newName, newInstitution);
    setIsGenerateModalOpen(false);
    setNewName('');
  };

  const handleCopyDoc = () => {
    if (!selectedDoc) return;
    navigator.clipboard.writeText(JSON.stringify(selectedDoc, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="did-management-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-cyan-400">W3C DID REGISTRY</span>
            <Badge variant="cyan" dot>
              Decentralized Identity Engine
            </Badge>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">
            Decentralized Identity (DID) Management
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Self-sovereign cryptographic identifiers anchored to the HealthChain consortium. Each entity (Patient, Doctor, Administrator, and IoMT device) possesses an immutable decentralized identifier decoupled from centralized identity providers.
          </p>
        </div>

        <button
          id="btn-open-generate-did"
          onClick={() => setIsGenerateModalOpen(true)}
          className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-semibold flex items-center gap-2 transition-all shadow-md shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Generate DID</span>
        </button>
      </div>

      {/* DID Architecture Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-200 font-sans">Self-Sovereign Identity</h4>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              Patients own their identity. Private keys remain under local client custody, never exposed to hospital servers or databases.
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 shrink-0">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-200 font-sans">Cross-Institutional Federation</h4>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              A single DID is globally resolved across CityCare, Sanjivani, Apollo, and Rural clinics without central lock-in.
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-indigo-950/60 border border-indigo-500/30 text-indigo-400 shrink-0">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-200 font-sans">Ed25519 Cryptography</h4>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              Digital signatures and zero-knowledge proofs enable instant verification on the immutable blockchain ledger.
            </p>
          </div>
        </div>
      </div>

      {/* Main DID Table */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Fingerprint className="w-4 h-4 text-emerald-400" /> Active HealthChain DID Registry
            </h3>
            <p className="text-[11px] text-slate-400">
              Registered decentralized identities across humans and medical IoT hardware
            </p>
          </div>
          <Badge variant="emerald">{dids.length} Identities Minted</Badge>
        </div>

        <div className="overflow-x-auto mt-3">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Entity Name</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Decentralized Identifier (DID)</th>
                <th className="py-2.5 px-3">Institution</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {dids.map((identity) => {
                const isVerified = identity.verificationStatus === 'VERIFIED';
                return (
                  <tr key={identity.did} id={`did-row-${identity.did}`} className="hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-sans font-medium text-slate-200">
                      {identity.name}
                    </td>
                    <td className="py-3 px-3">
                      <Badge
                        variant={
                          identity.type === 'Patient'
                            ? 'emerald'
                            : identity.type === 'Doctor'
                            ? 'cyan'
                            : identity.type === 'IoMT_Device'
                            ? 'violet'
                            : 'indigo'
                        }
                      >
                        {identity.type}
                      </Badge>
                    </td>
                    <td className="py-3 px-3 text-cyan-300 font-semibold">{identity.did}</td>
                    <td className="py-3 px-3 text-slate-400">{identity.institution}</td>
                    <td className="py-3 px-3">
                      {isVerified ? (
                        <span className="text-emerald-400 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                        </span>
                      ) : (
                        <span className="text-amber-400 font-semibold flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" /> Pending
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right space-x-1.5 whitespace-nowrap">
                      {!isVerified && (
                        <button
                          id={`btn-verify-did-${identity.did}`}
                          onClick={() => handleVerifyDID(identity.did)}
                          className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-sans font-semibold text-[11px] transition-colors"
                        >
                          Verify DID
                        </button>
                      )}
                      <button
                        id={`btn-view-doc-${identity.did}`}
                        onClick={() => handleViewDoc(identity)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 font-sans font-medium text-[11px] transition-colors inline-flex items-center gap-1"
                      >
                        <FileCode className="w-3 h-3" /> View DID Document
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* GENERATE DID MODAL */}
      <Modal
        isOpen={isGenerateModalOpen}
        onClose={() => setIsGenerateModalOpen(false)}
        title="Generate New Decentralized Identity (DID)"
        subtitle="Simulate keypair generation and anchor new identity onto the consortium ledger"
        maxWidth="md"
      >
        <form onSubmit={handleGenerateSubmit} className="space-y-4 text-xs font-sans">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Identity Type</label>
            <select
              value={newType}
              onChange={(e) =>
                setNewType(
                  e.target.value as 'Patient' | 'Doctor' | 'Administrator' | 'IoMT_Device'
                )
              }
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-cyan-500 font-mono text-xs"
            >
              <option value="Patient">Patient</option>
              <option value="Doctor">Doctor / Specialist</option>
              <option value="Administrator">Hospital Administrator</option>
              <option value="IoMT_Device">IoMT Medical Device</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Entity / Person Name</label>
            <input
              type="text"
              required
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. Dr. Emily Chen, or Smart Insulin Pump"
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-cyan-500 font-mono text-xs"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Affiliated Institution</label>
            <select
              value={newInstitution}
              onChange={(e) => setNewInstitution(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-cyan-500 font-mono text-xs"
            >
              <option value="CityCare Hospital">CityCare Hospital</option>
              <option value="Sanjivani Medical Center">Sanjivani Medical Center</option>
              <option value="Apollo Health Center">Apollo Health Center</option>
              <option value="Rural Health Clinic">Rural Health Clinic</option>
            </select>
          </div>

          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-400 font-mono space-y-1">
            <div className="text-emerald-400 font-semibold">Decentralized Format Specification:</div>
            <div>Pattern: did:health:{newType.toLowerCase().replace(/[^a-z]/g, '')}:[4-hex]</div>
            <div>Key Suite: Ed25519VerificationKey2020</div>
            <div className="text-slate-500">Private keys generated client-side and never broadcast.</div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsGenerateModalOpen(false)}
              className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-semibold flex items-center gap-1.5"
            >
              <Fingerprint className="w-4 h-4" /> Mint Decentralized ID
            </button>
          </div>
        </form>
      </Modal>

      {/* VIEW DID DOCUMENT MODAL */}
      {selectedDoc && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedDoc(null)}
          title="W3C DID Document"
          subtitle={`Cryptographic JSON-LD document for ${selectedDoc.id}`}
          maxWidth="2xl"
        >
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-cyan-300">
                Specification: W3C Decentralized Identifiers v1.0
              </span>
              <button
                onClick={handleCopyDoc}
                className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono flex items-center gap-1.5 border border-slate-700 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy JSON'}</span>
              </button>
            </div>

            <pre className="p-4 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-mono text-emerald-300 overflow-x-auto max-h-96 custom-scrollbar leading-relaxed">
              {JSON.stringify(selectedDoc, null, 2)}
            </pre>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedDoc(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
