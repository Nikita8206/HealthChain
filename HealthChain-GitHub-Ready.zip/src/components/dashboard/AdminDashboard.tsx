import React, { useState, useEffect } from 'react';
import {
  User,
  Institution,
  IoMTDevice,
  AccessRequest,
  BlockchainBlock,
  SecurityEvent,
  BlockchainTransaction,
} from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { blockchainService } from '../../services/blockchainService';
import { Badge } from '../common/Badge';
import {
  ShieldCheck,
  Users,
  Building2,
  Activity,
  KeyRound,
  ShieldAlert,
  Blocks,
  RefreshCw,
  Server,
  ArrowUpRight,
} from 'lucide-react';

interface AdminDashboardProps {
  currentUser: User;
  onNavigateTab: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  onNavigateTab,
}) => {
  const [users, setUsers] = useState<User[]>([]);
  const [institutions, setInstitutions] = useState<Institution[]>([]);
  const [devices, setDevices] = useState<IoMTDevice[]>([]);
  const [requests, setRequests] = useState<AccessRequest[]>([]);
  const [blocks, setBlocks] = useState<BlockchainBlock[]>([]);
  const [transactions, setTransactions] = useState<BlockchainTransaction[]>([]);
  const [securityEvents, setSecurityEvents] = useState<SecurityEvent[]>([]);
  const [activeSubTab, setActiveSubTab] = useState<'users' | 'institutions' | 'iomt' | 'security'>(
    'users'
  );

  useEffect(() => {
    const update = () => {
      setUsers(storageService.getUsers());
      setInstitutions(storageService.getInstitutions());
      setDevices(storageService.getIoMTDevices());
      setRequests(storageService.getAccessRequests());
      setBlocks(storageService.getBlocks());
      setTransactions(storageService.getTransactions());
      setSecurityEvents(storageService.getSecurityEvents());
    };
    update();
    return subscribeToStorage(update);
  }, []);

  const totalPatients = users.filter((u) => u.role === 'patient').length;
  const totalDoctors = users.filter((u) => u.role === 'doctor').length;
  const chainIntegrity = blockchainService.verifyChainIntegrity();

  return (
    <div id="admin-dashboard-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-medium text-emerald-400">NETWORK GOVERNANCE</span>
              <Badge variant="emerald" dot>
                Federated Consensus Active
              </Badge>
            </div>
            <h2 className="text-xl font-bold text-slate-100 mt-1">Multi-Institutional Consortium Overview</h2>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-slate-400 font-mono">
              <span>Admin: {currentUser.name}</span>
              <span>DID: {currentUser.did}</span>
              <span>Network Protocol: Hyperledger PBFT Simulation</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-admin-verify-chain"
              onClick={() => {
                const res = blockchainService.verifyChainIntegrity();
                alert(res.details);
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-mono font-medium flex items-center gap-1.5 border border-slate-700"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Verify Merkle Root</span>
            </button>
            <button
              onClick={() => onNavigateTab('security')}
              className="px-3.5 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-500/40 text-xs font-medium flex items-center gap-1.5"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Cybersecurity Center</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Key Metrics (8 Stats) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>TOTAL USERS</span>
            <Users className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1.5">{users.length}</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
            {totalPatients} Patients • {totalDoctors} Doctors
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>INSTITUTIONS</span>
            <Building2 className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1.5">
            {institutions.length}
          </div>
          <div className="text-[10px] text-emerald-400 font-mono mt-0.5">100% Peer Verified</div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>IOMT DEVICES</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1.5">{devices.length}</div>
          <div className="text-[10px] text-emerald-400 font-mono mt-0.5">Live Telemetry Active</div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>BLOCKCHAIN TXS</span>
            <Blocks className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1.5">
            {transactions.length}
          </div>
          <div className="text-[10px] text-cyan-400 font-mono mt-0.5">
            {blocks.length} Blocks Sealed
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>ACCESS REQS</span>
            <KeyRound className="w-4 h-4 text-violet-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1.5">
            {requests.length}
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">Dynamic consent pipeline</div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>SECURITY AUDIT</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-400 mt-1.5">
            {securityEvents.length}
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">Monitored incidents</div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>CONSENSUS NODES</span>
            <Server className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1.5">4 / 4</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">PBFT Endorsers Synced</div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>LEDGER HEALTH</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1.5">
            {chainIntegrity.isValid ? '100%' : 'Audit'}
          </div>
          <div className="text-[10px] text-emerald-400 font-mono mt-0.5">Blockchain Verified</div>
        </div>
      </div>

      {/* Sub-tabs for Admin Detail Views */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => setActiveSubTab('users')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-medium font-mono transition-all ${
              activeSubTab === 'users'
                ? 'bg-slate-800 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Users & DIDs ({users.length})
          </button>
          <button
            onClick={() => setActiveSubTab('institutions')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-medium font-mono transition-all ${
              activeSubTab === 'institutions'
                ? 'bg-slate-800 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Institutions ({institutions.length})
          </button>
          <button
            onClick={() => setActiveSubTab('iomt')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-medium font-mono transition-all ${
              activeSubTab === 'iomt'
                ? 'bg-slate-800 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            IoMT Devices ({devices.length})
          </button>
          <button
            onClick={() => setActiveSubTab('security')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-medium font-mono transition-all ${
              activeSubTab === 'security'
                ? 'bg-slate-800 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Security Events ({securityEvents.length})
          </button>
        </div>

        {/* Tab 1: Users */}
        {activeSubTab === 'users' && (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Name</th>
                  <th className="py-2.5 px-3">Role</th>
                  <th className="py-2.5 px-3">Decentralized ID (DID)</th>
                  <th className="py-2.5 px-3">Institution</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-200">{u.name}</td>
                    <td className="py-2.5 px-3">
                      <Badge
                        variant={
                          u.role === 'doctor' ? 'cyan' : u.role === 'patient' ? 'emerald' : 'indigo'
                        }
                      >
                        {u.role.toUpperCase()}
                      </Badge>
                    </td>
                    <td className="py-2.5 px-3 text-cyan-300">{u.did}</td>
                    <td className="py-2.5 px-3 text-slate-400">{u.institution}</td>
                    <td className="py-2.5 px-3 text-emerald-400">✓ Active</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab 2: Institutions */}
        {activeSubTab === 'institutions' && (
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {institutions.map((inst) => (
              <div
                key={inst.id}
                className="p-4 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono space-y-2"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-slate-100 font-bold font-sans text-sm">{inst.name}</h4>
                  <Badge variant="emerald">Trust: {inst.trustScore}%</Badge>
                </div>
                <div className="text-slate-400 text-[11px]">Peer Node: {inst.didRegistryNode}</div>
                <div className="flex justify-between text-slate-400 text-[11px] pt-1 border-t border-slate-900">
                  <span>Location: {inst.location}</span>
                  <span>
                    {inst.doctorsCount} Drs • {inst.patientsCount} Patients
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 3: IoMT */}
        {activeSubTab === 'iomt' && (
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {devices.map((dev) => (
              <div
                key={dev.id}
                className="p-4 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-slate-100 font-bold font-sans">{dev.name}</span>
                  <Badge variant={dev.status === 'ONLINE' ? 'emerald' : 'rose'} dot>
                    {dev.status}
                  </Badge>
                </div>
                <div className="text-cyan-300 text-[11px]">DID: {dev.did}</div>
                <div className="text-slate-400 text-[11px]">
                  Patient: {dev.patientName} • Firmware: {dev.firmware}
                </div>
                <div className="text-slate-400 text-[11px]">Battery: {dev.battery}%</div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 4: Security Events */}
        {activeSubTab === 'security' && (
          <div className="mt-4 space-y-2 font-mono text-xs">
            {securityEvents.map((evt) => (
              <div
                key={evt.id}
                className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-start justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <Badge variant={evt.severity === 'CRITICAL' ? 'rose' : 'amber'}>
                      {evt.type}
                    </Badge>
                    <span className="text-slate-200 font-sans font-medium">
                      {evt.description}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    Actor: {evt.actorDid} • Institution: {evt.institution}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    Action: {evt.actionTaken}
                  </div>
                </div>
                <span className="text-[10px] text-slate-500 shrink-0">
                  {new Date(evt.timestamp).toLocaleTimeString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Navigation Links */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button
          onClick={() => onNavigateTab('blockchain')}
          className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 text-left transition-all group"
        >
          <div className="flex items-center justify-between text-slate-200 font-semibold text-xs">
            <span className="flex items-center gap-2">
              <Blocks className="w-4 h-4 text-emerald-400" />
              Explore Blockchain Ledger
            </span>
            <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-400" />
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Audit cryptographic hash pointers and Merkle roots across all blocks.
          </p>
        </button>

        <button
          onClick={() => onNavigateTab('security')}
          className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-rose-500/40 text-left transition-all group"
        >
          <div className="flex items-center justify-between text-slate-200 font-semibold text-xs">
            <span className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              Cybersecurity Monitoring
            </span>
            <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-rose-400" />
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Review unauthorized EHR access attempts, revoked tokens, and IoMT anomalies.
          </p>
        </button>

        <button
          onClick={() => onNavigateTab('institutions')}
          className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 text-left transition-all group"
        >
          <div className="flex items-center justify-between text-slate-200 font-semibold text-xs">
            <span className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-cyan-400" />
              Multi-Institution Federation
            </span>
            <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-cyan-400" />
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            View peer node distribution across CityCare, Sanjivani, Apollo, and Rural Clinic.
          </p>
        </button>
      </div>
    </div>
  );
};
