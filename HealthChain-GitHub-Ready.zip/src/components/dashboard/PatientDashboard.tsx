import React, { useState, useEffect } from 'react';
import { User, AccessRequest, Permission, EHRRecord, BlockchainTransaction } from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { authorizationService } from '../../services/authorizationService';
import { Badge } from '../common/Badge';
import {
  ShieldCheck,
  Activity,
  Heart,
  Droplet,
  Zap,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Building2,
  ArrowRight,
  ShieldAlert,
  FileCheck,
  Blocks,
  Eye,
} from 'lucide-react';

interface PatientDashboardProps {
  currentUser: User;
  onNavigateTab: (tab: string) => void;
}

export const PatientDashboard: React.FC<PatientDashboardProps> = ({
  currentUser,
  onNavigateTab,
}) => {
  const [requests, setRequests] = useState<AccessRequest[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [records, setRecords] = useState<EHRRecord[]>([]);
  const [transactions, setTransactions] = useState<BlockchainTransaction[]>([]);
  const [selectedRecord, setSelectedRecord] = useState<EHRRecord | null>(null);

  useEffect(() => {
    const update = () => {
      const allReqs = storageService.getAccessRequests();
      setRequests(allReqs.filter((r) => r.patientDid === currentUser.did));

      const allPerms = storageService.getPermissions();
      setPermissions(allPerms.filter((p) => p.patientDid === currentUser.did));

      setRecords(storageService.getEHRRecordsForPatient(currentUser.did));

      const allTxs = storageService.getTransactions();
      setTransactions(allTxs.filter((t) => t.patientDid === currentUser.did).slice(0, 5));
    };

    update();
    return subscribeToStorage(update);
  }, [currentUser.did]);

  const pendingRequests = requests.filter((r) => r.status === 'PENDING');
  const activePermissions = permissions.filter((p) => p.status === 'ACTIVE');

  const handleApprove = (requestId: string) => {
    authorizationService.approveAccessRequest(requestId);
  };

  const handleReject = (requestId: string) => {
    authorizationService.rejectAccessRequest(requestId);
  };

  const handleRevoke = (permissionId: string) => {
    authorizationService.revokePermission(permissionId);
  };

  return (
    <div id="patient-dashboard-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner & Overview Card */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 relative overflow-hidden shadow-lg">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-medium text-emerald-400">PATIENT CONSOLE</span>
              <Badge variant="emerald" dot>
                Self-Sovereign Identity Active
              </Badge>
            </div>
            <h2 className="text-xl font-bold text-slate-100 mt-1">{currentUser.name}</h2>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-slate-400 font-mono">
              <span className="flex items-center gap-1">
                DID: <span className="text-cyan-300 font-semibold">{currentUser.did}</span>
              </span>
              <span className="flex items-center gap-1">
                Primary: <span className="text-slate-200">{currentUser.institution}</span>
              </span>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex flex-wrap gap-2.5">
            <div className="px-3.5 py-2 rounded-lg bg-slate-800/80 border border-slate-700/60 min-w-[100px]">
              <div className="text-[10px] text-slate-400 font-mono">EHR RECORDS</div>
              <div className="text-lg font-bold text-slate-100">{records.length}</div>
            </div>
            <div className="px-3.5 py-2 rounded-lg bg-slate-800/80 border border-slate-700/60 min-w-[100px]">
              <div className="text-[10px] text-slate-400 font-mono">ACTIVE PERMS</div>
              <div className="text-lg font-bold text-emerald-400">{activePermissions.length}</div>
            </div>
            <div className="px-3.5 py-2 rounded-lg bg-slate-800/80 border border-slate-700/60 min-w-[100px]">
              <div className="text-[10px] text-slate-400 font-mono">PENDING REQS</div>
              <div className="text-lg font-bold text-amber-400">{pendingRequests.length}</div>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION A & SECTION B GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SECTION A: Patient Identity Details */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-cyan-400" /> Section A: Patient Identity
              </h3>
              <Badge variant="cyan">W3C Compliant</Badge>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Decentralized Identifier (DID):</span>
                <span className="font-mono text-cyan-300 font-medium break-all">{currentUser.did}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Identity Status:</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-1 font-mono">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Identity Type:</span>
                <span className="text-slate-200 font-mono">Decentralized Identity (DID)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Cryptography:</span>
                <span className="text-slate-300 font-mono">Ed25519Signature2020</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Registered Institutions:</span>
                <span className="text-slate-300 font-mono">4 Connected Peers</span>
              </div>
            </div>
          </div>

          <button
            id="btn-view-did-doc"
            onClick={() => onNavigateTab('did')}
            className="mt-4 w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-mono font-medium flex items-center justify-center gap-1.5 transition-colors border border-slate-700"
          >
            <span>View Full DID Document</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* SECTION B: Health Summary (Vitals) */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" /> Section B: Health Summary & Vitals
              </h3>
              <p className="text-[11px] text-slate-400">
                Encrypted simulated telemetry streams from federated IoMT medical devices
              </p>
            </div>
            <button
              id="btn-nav-iomt"
              onClick={() => onNavigateTab('iomt')}
              className="text-xs text-emerald-400 hover:underline font-mono flex items-center gap-1"
            >
              IoMT Details &rarr;
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 mt-4">
            {/* Heart Rate */}
            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-colors">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Heart Rate</span>
                <Heart className="w-4 h-4 text-rose-400" />
              </div>
              <div className="mt-2 text-2xl font-bold font-mono text-slate-100">72</div>
              <div className="text-[11px] text-emerald-400 font-mono mt-0.5">BPM • Normal</div>
            </div>

            {/* Blood Pressure */}
            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-colors">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Blood Pressure</span>
                <Activity className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="mt-2 text-xl font-bold font-mono text-slate-100">128/82</div>
              <div className="text-[11px] text-emerald-400 font-mono mt-0.5">mmHg • Stable</div>
            </div>

            {/* Blood Oxygen */}
            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-colors">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Blood Oxygen</span>
                <Droplet className="w-4 h-4 text-cyan-400" />
              </div>
              <div className="mt-2 text-2xl font-bold font-mono text-slate-100">98%</div>
              <div className="text-[11px] text-cyan-400 font-mono mt-0.5">SpO2 • Optimal</div>
            </div>

            {/* Blood Glucose */}
            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-colors">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Blood Glucose</span>
                <Zap className="w-4 h-4 text-amber-400" />
              </div>
              <div className="mt-2 text-2xl font-bold font-mono text-slate-100">108</div>
              <div className="text-[11px] text-emerald-400 font-mono mt-0.5">mg/dL • Fasting</div>
            </div>
          </div>

          <div className="mt-3 text-[11px] text-slate-400 flex items-center gap-2 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Telemetry verified via IoMT DID Signature • Omron V-10 & Dexcom GSim</span>
          </div>
        </div>
      </div>

      {/* SECTION C: EHR Summary */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-indigo-400" /> Section C: Electronic Health Records (EHR) Summary
            </h3>
            <p className="text-[11px] text-slate-400">
              Patient-sovereign health records. Only shared when dynamic patient consent is active.
            </p>
          </div>
          <button
            id="btn-nav-ehr-all"
            onClick={() => onNavigateTab('ehr')}
            className="text-xs text-cyan-400 hover:underline font-mono"
          >
            View All Records &rarr;
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-4">
          {records.slice(0, 6).map((rec) => (
            <div
              key={rec.id}
              className="p-3.5 rounded-lg bg-slate-950 border border-slate-800/90 hover:border-slate-700 transition-all cursor-pointer flex flex-col justify-between"
              onClick={() => setSelectedRecord(rec)}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded bg-slate-800 text-indigo-300">
                    {rec.recordType}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">{rec.hospital}</span>
                </div>
                <h4 className="text-xs font-semibold text-slate-200 mt-2 line-clamp-1">{rec.title}</h4>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{rec.clinicalNotes}</p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                <span>Date: {rec.createdDate}</span>
                <span className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono">
                  <Eye className="w-3 h-3" /> Inspect
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION D: Access Requests (Approve / Reject) */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" /> Section D: Pending Doctor Access Requests
            </h3>
            <p className="text-[11px] text-slate-400">
              Physicians must request patient consent before accessing confidential medical records
            </p>
          </div>
          <Badge variant={pendingRequests.length > 0 ? 'amber' : 'slate'} dot={pendingRequests.length > 0}>
            {pendingRequests.length} Pending
          </Badge>
        </div>

        {pendingRequests.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400 font-mono">
            No pending access requests. All current requests have been processed.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80 mt-2">
            {pendingRequests.map((req) => (
              <div
                key={req.id}
                id={`request-item-${req.id}`}
                className="py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-100">{req.doctorName}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                      {req.institution}
                    </span>
                    {req.isEmergency && (
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-500/30">
                        EMERGENCY
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-300">
                    Requested Scope:{' '}
                    <span className="text-emerald-300 font-mono font-medium">
                      {req.requestedRecords.join(', ')}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Purpose: &quot;{req.purpose}&quot; • Duration: {req.accessDurationHours} hours
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    id={`btn-approve-req-${req.id}`}
                    onClick={() => handleApprove(req.id)}
                    className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Approve Access
                  </button>
                  <button
                    id={`btn-reject-req-${req.id}`}
                    onClick={() => handleReject(req.id)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/80 hover:text-rose-300 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-700"
                  >
                    <XCircle className="w-4 h-4" /> Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SECTION E: Active Permissions (View / Revoke) */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-emerald-400" /> Section E: Active Permissions & Dynamic Consent
            </h3>
            <p className="text-[11px] text-slate-400">
              Patients maintain permanent self-sovereignty. You can revoke any doctor&apos;s permission at any time.
            </p>
          </div>
          <Badge variant="emerald">{activePermissions.length} Active Grants</Badge>
        </div>

        {activePermissions.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400 font-mono">
            No active permissions. Doctors cannot access your EHR records until granted.
          </div>
        ) : (
          <div className="overflow-x-auto mt-3">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Doctor</th>
                  <th className="py-2.5 px-3">Institution</th>
                  <th className="py-2.5 px-3">Record Type</th>
                  <th className="py-2.5 px-3">Permission</th>
                  <th className="py-2.5 px-3">Granted Date</th>
                  <th className="py-2.5 px-3">Expiry Date</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {activePermissions.map((perm) => (
                  <tr key={perm.id} id={`perm-row-${perm.id}`} className="hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-sans font-medium text-slate-200">
                      {perm.doctorName}
                    </td>
                    <td className="py-3 px-3 text-slate-400">{perm.institution}</td>
                    <td className="py-3 px-3">
                      <span className="text-emerald-300 font-medium">{perm.recordTypes.join(', ')}</span>
                    </td>
                    <td className="py-3 px-3">
                      <Badge variant="cyan">{perm.permissionLevel}</Badge>
                    </td>
                    <td className="py-3 px-3 text-slate-400 text-[11px]">
                      {new Date(perm.grantedDate).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-3 text-slate-400 text-[11px]">
                      {new Date(perm.expiryDate).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-emerald-400 font-semibold flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        ACTIVE
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        id={`btn-revoke-perm-${perm.id}`}
                        onClick={() => handleRevoke(perm.id)}
                        className="px-2.5 py-1 rounded bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-500/40 text-[11px] font-semibold transition-colors"
                      >
                        Revoke Access
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Recent Blockchain Transactions */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Blocks className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-slate-200">Recent Blockchain Transactions</h3>
          </div>
          <button
            onClick={() => onNavigateTab('blockchain')}
            className="text-xs text-cyan-400 hover:underline font-mono"
          >
            Ledger Explorer &rarr;
          </button>
        </div>

        <div className="mt-3 space-y-2">
          {transactions.map((tx) => (
            <div
              key={tx.id}
              className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between gap-3 text-xs"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <Badge variant={tx.type.includes('DENIED') ? 'rose' : 'emerald'}>{tx.type}</Badge>
                  <span className="font-mono text-slate-400 text-[11px]">
                    Hash: {tx.txHash.slice(0, 16)}...
                  </span>
                </div>
                <p className="text-slate-300 text-xs">{tx.details}</p>
              </div>
              <span className="text-[10px] text-slate-400 font-mono shrink-0">
                {new Date(tx.timestamp).toLocaleTimeString()}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Record Inspect Modal */}
      {selectedRecord && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          onClick={() => setSelectedRecord(null)}
        >
          <div
            className="bg-slate-900 border border-slate-700 rounded-xl max-w-lg w-full p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-cyan-400 uppercase">
                  {selectedRecord.recordType}
                </span>
                <h3 className="text-base font-bold text-slate-100">{selectedRecord.title}</h3>
              </div>
              <button
                onClick={() => setSelectedRecord(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs font-mono">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
                {Object.entries(selectedRecord.data).map(([key, val]) => (
                  <div key={key} className="flex justify-between border-b border-slate-900 pb-1">
                    <span className="text-slate-400">{key}:</span>
                    <span className="text-emerald-300 font-medium">{String(val)}</span>
                  </div>
                ))}
              </div>

              <div>
                <span className="text-slate-400 block font-sans text-xs">Clinical Notes:</span>
                <p className="text-slate-300 font-sans text-xs mt-1 p-2 rounded bg-slate-950 border border-slate-800">
                  {selectedRecord.clinicalNotes}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
