import React, { useState, useEffect } from 'react';
import {
  User,
  AccessRequest,
  Permission,
  EHRRecord,
  EHRRecordType,
  BlockchainTransaction,
} from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { authorizationService } from '../../services/authorizationService';
import { ehrService } from '../../services/ehrService';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';
import {
  Stethoscope,
  Search,
  KeyRound,
  ShieldCheck,
  ShieldAlert,
  Send,
  Eye,
  CheckCircle2,
  AlertCircle,
  FileText,
  Clock,
  Flame,
  ArrowRight,
} from 'lucide-react';

interface DoctorDashboardProps {
  currentUser: User;
  onNavigateTab: (tab: string) => void;
}

export const DoctorDashboard: React.FC<DoctorDashboardProps> = ({
  currentUser,
  onNavigateTab,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [requests, setRequests] = useState<AccessRequest[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [allRecords, setAllRecords] = useState<EHRRecord[]>([]);
  const [transactions, setTransactions] = useState<BlockchainTransaction[]>([]);

  // Request Access Modal State
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [selectedPatientDid, setSelectedPatientDid] = useState('did:health:patient:001');
  const [selectedPatientName, setSelectedPatientName] = useState('Sarah Jenkins');
  const [selectedRecords, setSelectedRecords] = useState<EHRRecordType[]>(['Diagnosis', 'Prescription']);
  const [requestPurpose, setRequestPurpose] = useState('Metabolic therapy consultation and medication reconciliation');
  const [durationHours, setDurationHours] = useState<number>(24);

  // Authorization Evaluation Result Modal / Display
  const [authDecision, setAuthDecision] = useState<{
    show: boolean;
    granted: boolean;
    reason: string;
    recordTitle?: string;
    recordType?: string;
    recordData?: Record<string, string | number | boolean | string[]>;
    clinicalNotes?: string;
  } | null>(null);

  useEffect(() => {
    const update = () => {
      const allReqs = storageService.getAccessRequests();
      setRequests(allReqs.filter((r) => r.doctorDid === currentUser.did));

      const allPerms = storageService.getPermissions();
      setPermissions(allPerms.filter((p) => p.doctorDid === currentUser.did));

      setAllRecords(storageService.getEHRRecords());

      const allTxs = storageService.getTransactions();
      setTransactions(
        allTxs
          .filter(
            (t) =>
              t.actorDid === currentUser.did ||
              t.details.includes(currentUser.name) ||
              t.type === 'EHR_ACCESSED' ||
              t.type === 'EHR_ACCESS_DENIED'
          )
          .slice(0, 6)
      );
    };

    update();
    return subscribeToStorage(update);
  }, [currentUser.did, currentUser.name]);

  const activePermissions = permissions.filter((p) => p.status === 'ACTIVE');
  const pendingRequests = requests.filter((r) => r.status === 'PENDING');

  // Available Record Types
  const availableRecordTypes: EHRRecordType[] = [
    'Diagnosis',
    'Prescription',
    'Laboratory Report',
    'Allergy',
    'Treatment History',
    'Medical Notes',
    'Genetic Data',
  ];

  const handleToggleRecordType = (type: EHRRecordType) => {
    if (selectedRecords.includes(type)) {
      setSelectedRecords(selectedRecords.filter((t) => t !== type));
    } else {
      setSelectedRecords([...selectedRecords, type]);
    }
  };

  const handleSendAccessRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedRecords.length === 0) return;

    authorizationService.createAccessRequest({
      doctorDid: currentUser.did,
      doctorName: currentUser.name,
      patientDid: selectedPatientDid,
      patientName: selectedPatientName,
      institution: currentUser.institution,
      requestedRecords: selectedRecords,
      purpose: requestPurpose,
      accessDurationHours: Number(durationHours),
    });

    setIsRequestModalOpen(false);
  };

  // Test access to a specific record using the authorization service
  const handleAttemptRecordAccess = (record: EHRRecord) => {
    const result = ehrService.getRecordWithAuthorization({
      recordId: record.id,
      doctorDid: currentUser.did,
      doctorName: currentUser.name,
      institution: currentUser.institution,
    });

    if (result.success && result.record) {
      setAuthDecision({
        show: true,
        granted: true,
        reason: result.reason,
        recordTitle: result.record.title,
        recordType: result.record.recordType,
        recordData: result.record.data,
        clinicalNotes: result.record.clinicalNotes,
      });
    } else {
      setAuthDecision({
        show: true,
        granted: false,
        reason: result.reason,
        recordTitle: record.title,
        recordType: record.recordType,
      });
    }
  };

  const filteredRecords = allRecords.filter(
    (r) =>
      r.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.recordType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="doctor-dashboard-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Doctor Header Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-medium text-cyan-400">PHYSICIAN CONSOLE</span>
              <Badge variant="cyan" dot>
                Authorized Clinical Node
              </Badge>
            </div>
            <h2 className="text-xl font-bold text-slate-100 mt-1">{currentUser.name}</h2>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-slate-400 font-mono">
              <span>
                DID: <span className="text-emerald-300 font-semibold">{currentUser.did}</span>
              </span>
              <span>
                Hospital: <span className="text-slate-200">{currentUser.institution}</span>
              </span>
              <span>Specialty: Cardiology & Internal Medicine</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5">
            <button
              id="btn-open-request-modal"
              onClick={() => setIsRequestModalOpen(true)}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-semibold flex items-center gap-2 transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
              <span>Request Patient Access</span>
            </button>
            <button
              id="btn-nav-emergency"
              onClick={() => onNavigateTab('emergency')}
              className="px-3 py-2 rounded-lg bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-500/40 text-xs font-medium flex items-center gap-1.5 transition-all"
            >
              <Flame className="w-4 h-4 text-rose-400" />
              <span>Break-Glass</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="text-[11px] text-slate-400 font-mono">AUTHORIZED CONSENTS</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {activePermissions.length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Active cryptographic grants</div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="text-[11px] text-slate-400 font-mono">PENDING REQUESTS</div>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
            {pendingRequests.length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Awaiting patient consent</div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="text-[11px] text-slate-400 font-mono">FEDERATED PATIENTS</div>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">1</div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Sarah Jenkins (Verified DID)</div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="text-[11px] text-slate-400 font-mono">ENFORCEMENT POLICY</div>
          <div className="text-xs font-semibold text-slate-200 mt-2 font-mono flex items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Dynamic RBAC + ABAC
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Zero Trust Architecture</div>
        </div>
      </div>

      {/* EHR Search & Access Authorization Tester */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-400" /> Patient Directory & Dynamic Authorization Access
            </h3>
            <p className="text-[11px] text-slate-400">
              Doctors do NOT automatically have access to records. Each query dynamically validates patient consent, record scope, institution, and expiration.
            </p>
          </div>

          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              id="input-search-ehr"
              placeholder="Search records or patient..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
            />
          </div>
        </div>

        {/* Record Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 mt-4">
          {filteredRecords.map((rec) => {
            // Check current status preview
            const hasPerm = activePermissions.some(
              (p) => p.patientDid === rec.patientDid && p.recordTypes.includes(rec.recordType)
            );
            const isRestricted = rec.recordType === 'Genetic Data';

            return (
              <div
                key={rec.id}
                id={`record-card-${rec.id}`}
                className="p-4 rounded-lg bg-slate-950 border border-slate-800/90 hover:border-slate-700 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded bg-slate-800 text-indigo-300">
                      {rec.recordType}
                    </span>
                    {hasPerm ? (
                      <Badge variant="emerald" dot>
                        Permitted
                      </Badge>
                    ) : (
                      <Badge variant={isRestricted ? 'rose' : 'slate'}>
                        {isRestricted ? 'Restricted' : 'Consent Required'}
                      </Badge>
                    )}
                  </div>

                  <h4 className="text-xs font-bold text-slate-100 mt-2.5 line-clamp-1">
                    {rec.title}
                  </h4>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">
                    Patient: <span className="text-slate-300">{rec.patientName}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                    Hospital: {rec.hospital}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-900 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400 font-mono">
                    Access Level: {rec.accessLevel}
                  </span>
                  <button
                    id={`btn-access-record-${rec.id}`}
                    onClick={() => handleAttemptRecordAccess(rec)}
                    className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-mono font-medium flex items-center gap-1 transition-colors border border-slate-700"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Query Record</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Active Permissions & Recent Access Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Doctor Permissions */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-emerald-400" /> Your Active Permissions
            </h3>
            <Badge variant="emerald">{activePermissions.length} Active</Badge>
          </div>

          {activePermissions.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400 font-mono">
              No active permissions. Click &quot;Request Patient Access&quot; to initiate workflow.
            </div>
          ) : (
            <div className="mt-3 space-y-2.5">
              {activePermissions.map((perm) => (
                <div
                  key={perm.id}
                  className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-slate-100 font-sans font-medium">
                      {perm.patientName} ({perm.patientDid})
                    </span>
                    <span className="text-emerald-400 text-[10px]">● ACTIVE</span>
                  </div>
                  <div className="text-slate-400 text-[11px]">
                    Authorized Scope:{' '}
                    <span className="text-emerald-300">{perm.recordTypes.join(', ')}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1">
                    <span>Expires: {new Date(perm.expiryDate).toLocaleString()}</span>
                    <span>Tx: {perm.transactionHash.slice(0, 10)}...</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Blockchain Audit & Decisions */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-cyan-400" /> Recent Authorization & Audit Events
            </h3>
            <button
              onClick={() => onNavigateTab('blockchain')}
              className="text-xs text-cyan-400 hover:underline font-mono"
            >
              Full Ledger &rarr;
            </button>
          </div>

          <div className="mt-3 space-y-2">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-xs font-mono flex items-start justify-between gap-2"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <Badge variant={tx.type.includes('DENIED') ? 'rose' : 'emerald'}>
                      {tx.type}
                    </Badge>
                    <span className="text-[10px] text-slate-400 truncate font-sans">
                      {tx.details}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">Hash: {tx.txHash.slice(0, 16)}...</div>
                </div>
                <span className="text-[10px] text-slate-400 shrink-0">
                  {new Date(tx.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* REQUEST ACCESS MODAL */}
      <Modal
        isOpen={isRequestModalOpen}
        onClose={() => setIsRequestModalOpen(false)}
        title="Request Dynamic Patient Access"
        subtitle="Submit cryptographic access request to patient's decentralized consent controller"
        maxWidth="lg"
      >
        <form onSubmit={handleSendAccessRequest} className="space-y-4 text-xs font-sans">
          {/* Patient selection */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Target Patient DID</label>
            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono flex items-center justify-between">
              <span>{selectedPatientName}</span>
              <span className="text-cyan-300">{selectedPatientDid}</span>
            </div>
          </div>

          {/* Record types checkboxes */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">
              Select Requested Record Types (Granular Scope)
            </label>
            <div className="grid grid-cols-2 gap-2">
              {availableRecordTypes.map((type) => {
                const checked = selectedRecords.includes(type);
                return (
                  <button
                    type="button"
                    key={type}
                    id={`checkbox-record-${type.replace(/\s+/g, '-')}`}
                    onClick={() => handleToggleRecordType(type)}
                    className={`p-2 rounded-lg border text-left flex items-center justify-between font-mono text-xs transition-all ${
                      checked
                        ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <span>{type}</span>
                    {checked && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Purpose */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Clinical Purpose</label>
            <input
              type="text"
              id="input-request-purpose"
              value={requestPurpose}
              onChange={(e) => setRequestPurpose(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-cyan-500 font-mono text-xs"
              placeholder="e.g. Follow-up consultation for metabolic management"
            />
          </div>

          {/* Duration */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Access Duration (Hours)</label>
            <select
              id="select-request-duration"
              value={durationHours}
              onChange={(e) => setDurationHours(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-cyan-500 font-mono text-xs"
            >
              <option value={1}>1 Hour (Emergency/Single Consult)</option>
              <option value={4}>4 Hours (Outpatient Visit)</option>
              <option value={24}>24 Hours (Standard Clinic Day)</option>
              <option value={72}>72 Hours (Inpatient Multi-Day)</option>
            </select>
          </div>

          {/* Submit */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={() => setIsRequestModalOpen(false)}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="btn-submit-access-request"
              disabled={selectedRecords.length === 0}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-slate-950 text-xs font-semibold flex items-center gap-1.5 shadow-sm"
            >
              <Send className="w-4 h-4" /> Send Access Request
            </button>
          </div>
        </form>
      </Modal>

      {/* DYNAMIC AUTHORIZATION RESULT MODAL (Clear feedback for Faculty Demo) */}
      {authDecision && (
        <Modal
          isOpen={authDecision.show}
          onClose={() => setAuthDecision(null)}
          title={authDecision.granted ? 'Access Granted' : 'Access Denied'}
          subtitle={
            authDecision.granted
              ? 'Cryptographic validation succeeded'
              : 'Zero Trust Policy Enforcement Triggered'
          }
          maxWidth="lg"
        >
          <div className="space-y-4 text-xs font-mono">
            {/* Status Banner */}
            <div
              className={`p-4 rounded-lg border flex items-start gap-3 ${
                authDecision.granted
                  ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
                  : 'bg-rose-950/80 border-rose-500/50 text-rose-200'
              }`}
            >
              {authDecision.granted ? (
                <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
              )}
              <div>
                <h4 className="text-sm font-bold tracking-tight">
                  {authDecision.granted ? 'ACCESS GRANTED' : 'ACCESS DENIED'}
                </h4>
                <p className="text-xs mt-1 leading-relaxed opacity-90">{authDecision.reason}</p>
              </div>
            </div>

            {/* If Granted: Show the decrypted EHR Data */}
            {authDecision.granted && authDecision.recordData && (
              <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-xs font-bold text-slate-100 font-sans">
                    {authDecision.recordTitle}
                  </span>
                  <Badge variant="cyan">{authDecision.recordType}</Badge>
                </div>

                <div className="space-y-1.5">
                  {Object.entries(authDecision.recordData).map(([k, v]) => (
                    <div key={k} className="flex justify-between border-b border-slate-900 pb-1">
                      <span className="text-slate-400">{k}:</span>
                      <span className="text-emerald-300 font-medium">{String(v)}</span>
                    </div>
                  ))}
                </div>

                {authDecision.clinicalNotes && (
                  <div className="mt-2 pt-2 border-t border-slate-800">
                    <span className="text-slate-400 block text-[11px] font-sans">Physician Notes:</span>
                    <p className="text-slate-300 font-sans text-xs mt-0.5">
                      {authDecision.clinicalNotes}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* If Denied: Explain why and offer Request button */}
            {!authDecision.granted && (
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 space-y-2">
                <p className="font-sans text-xs">
                  To view this record, you must obtain active patient consent from Sarah Jenkins for the
                  &quot;{authDecision.recordType}&quot; scope, or request temporary Emergency Access if clinically justified.
                </p>
                <div className="flex items-center gap-2 pt-2">
                  <button
                    onClick={() => {
                      setAuthDecision(null);
                      setIsRequestModalOpen(true);
                    }}
                    className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-semibold text-xs transition-colors"
                  >
                    Request Consent Now
                  </button>
                  <button
                    onClick={() => {
                      setAuthDecision(null);
                      onNavigateTab('emergency');
                    }}
                    className="px-3 py-1.5 rounded bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-500/40 text-xs font-semibold transition-colors"
                  >
                    Break-Glass Emergency
                  </button>
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setAuthDecision(null)}
                className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-sans font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
