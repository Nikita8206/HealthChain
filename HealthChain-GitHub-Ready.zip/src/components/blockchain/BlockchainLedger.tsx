import React, { useState, useEffect } from 'react';
import { BlockchainBlock, BlockchainTransaction } from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { blockchainService } from '../../services/blockchainService';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';
import {
  Blocks,
  ShieldCheck,
  Search,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Filter,
  Copy,
  Check,
  Hash,
  Clock,
  Server,
  Layers,
} from 'lucide-react';

export const BlockchainLedger: React.FC = () => {
  const [blocks, setBlocks] = useState<BlockchainBlock[]>([]);
  const [transactions, setTransactions] = useState<BlockchainTransaction[]>([]);
  const [selectedBlock, setSelectedBlock] = useState<BlockchainBlock | null>(null);
  const [selectedTx, setSelectedTx] = useState<BlockchainTransaction | null>(null);

  // Search & Filters
  const [searchHash, setSearchHash] = useState('');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [filterActor, setFilterActor] = useState<string>('ALL');

  // Chain verification status
  const [verifyResult, setVerifyResult] = useState<{
    tested: boolean;
    isValid: boolean;
    message: string;
  } | null>(null);

  const [copiedText, setCopiedText] = useState<string | null>(null);

  useEffect(() => {
    const update = () => {
      setBlocks(storageService.getBlocks());
      setTransactions(storageService.getTransactions());
    };
    update();
    return subscribeToStorage(update);
  }, []);

  const handleVerifyChain = () => {
    const res = blockchainService.verifyChainIntegrity();
    setVerifyResult({
      tested: true,
      isValid: res.isValid,
      message: res.details,
    });
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const txTypes = [
    'ALL',
    'DID_CREATED',
    'DID_VERIFIED',
    'ACCESS_REQUESTED',
    'ACCESS_APPROVED',
    'ACCESS_REJECTED',
    'ACCESS_REVOKED',
    'EHR_ACCESSED',
    'EHR_ACCESS_DENIED',
    'EMERGENCY_ACCESS',
    'IOMT_TELEMETRY_RECORDED',
  ];

  const filteredTxs = transactions.filter((tx) => {
    const matchesSearch =
      !searchHash ||
      tx.txHash.toLowerCase().includes(searchHash.toLowerCase()) ||
      tx.actorDid.toLowerCase().includes(searchHash.toLowerCase()) ||
      tx.details.toLowerCase().includes(searchHash.toLowerCase());

    const matchesType = filterType === 'ALL' || tx.type === filterType;
    const matchesActor = filterActor === 'ALL' || tx.actorDid === filterActor;

    return matchesSearch && matchesType && matchesActor;
  });

  return (
    <div id="blockchain-ledger-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-emerald-400">
              DISTRIBUTED CONSORTIUM LEDGER
            </span>
            <Badge variant="emerald" dot>
              PBFT Byzantine Consensus
            </Badge>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">
            Blockchain Ledger Explorer & Audit Chain
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Cryptographic ledger containing immutable records of decentralized identity generation, dynamic consent authorizations, EHR access audits, emergency break-glass occurrences, and IoMT telemetry streams.
          </p>
        </div>

        <button
          id="btn-verify-chain-integrity"
          onClick={handleVerifyChain}
          className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-semibold flex items-center gap-2 transition-all shadow-md shrink-0"
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Verify Chain Integrity</span>
        </button>
      </div>

      {/* Chain Integrity Alert Banner */}
      {verifyResult && (
        <div
          className={`p-4 rounded-xl border flex items-start justify-between gap-3 font-mono text-xs ${
            verifyResult.isValid
              ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
              : 'bg-rose-950/80 border-rose-500/50 text-rose-200'
          }`}
        >
          <div className="flex items-start gap-2.5">
            {verifyResult.isValid ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            )}
            <div>
              <div className="font-bold">
                {verifyResult.isValid
                  ? 'Blockchain Integrity: 100% Valid (All hashes match cryptographic sequence)'
                  : 'INTEGRITY MISMATCH DETECTED'}
              </div>
              <div className="text-[11px] opacity-90 mt-0.5">{verifyResult.message}</div>
            </div>
          </div>
          <button
            onClick={() => setVerifyResult(null)}
            className="text-slate-400 hover:text-slate-200 text-xs"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Visual Chain Representation (Horizontal Block Sequence) */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2 font-sans">
              <Layers className="w-4 h-4 text-emerald-400" /> Visual Block Sequence (Cryptographic Hash Pointers)
            </h3>
            <p className="text-[11px] text-slate-400 font-sans">
              Click any block to inspect its header, Merkle tree root, and embedded transactions.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">Total Blocks: {blocks.length}</span>
        </div>

        {/* Horizontal Block Carousel */}
        <div className="flex items-center gap-3 overflow-x-auto py-4 custom-scrollbar">
          {blocks.map((b, idx) => (
            <React.Fragment key={b.blockNumber}>
              <div
                id={`block-card-${b.blockNumber}`}
                onClick={() => setSelectedBlock(b)}
                className="w-56 shrink-0 p-3.5 rounded-lg bg-slate-950 border border-slate-800 hover:border-emerald-500/60 transition-all cursor-pointer group shadow-sm text-xs font-mono space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-400 font-sans">
                    {b.blockNumber === 0 ? 'Genesis #0' : `Block #${b.blockNumber}`}
                  </span>
                  <Badge variant={b.blockNumber === 0 ? 'indigo' : 'cyan'}>
                    {b.transactions.length} Txs
                  </Badge>
                </div>

                <div className="text-[10px] text-slate-400 truncate">
                  Hash: <span className="text-slate-300">{b.currentHash.slice(0, 14)}...</span>
                </div>
                <div className="text-[10px] text-slate-400 truncate">
                  Prev: <span className="text-slate-500">{b.previousHash.slice(0, 14)}...</span>
                </div>

                <div className="pt-2 border-t border-slate-900 flex items-center justify-between text-[10px] text-slate-400">
                  <span className="truncate">{b.validator.split(' ')[0]}</span>
                  <span>{new Date(b.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </div>

              {idx < blocks.length - 1 && (
                <div className="shrink-0 text-slate-600 flex items-center">
                  <ArrowRight className="w-5 h-5 text-emerald-500/60" />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Transaction Explorer & Audit Logs */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Hash className="w-4 h-4 text-cyan-400" /> Immutable Consortium Audit Log
            </h3>
            <p className="text-[11px] text-slate-400">
              Verified transactions anchored in blocks with cryptographic nonces
            </p>
          </div>

          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              id="input-search-tx-hash"
              value={searchHash}
              onChange={(e) => setSearchHash(e.target.value)}
              placeholder="Search by Tx Hash, DID, or details..."
              className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs font-mono placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        {/* Filter chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-mono custom-scrollbar">
          <Filter className="w-3.5 h-3.5 text-slate-500 shrink-0 mr-1" />
          {txTypes.map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-2.5 py-1 rounded text-[11px] whitespace-nowrap transition-all ${
                filterType === type
                  ? 'bg-cyan-600 text-slate-950 font-bold'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Transaction Hash</th>
                <th className="py-2.5 px-3">Actor DID</th>
                <th className="py-2.5 px-3">Details</th>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3 text-right">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredTxs.map((tx) => {
                const isDenied = tx.type.includes('DENIED');
                const isEmergency = tx.type.includes('EMERGENCY');
                return (
                  <tr key={tx.id} id={`tx-row-${tx.id}`} className="hover:bg-slate-800/30">
                    <td className="py-2.5 px-3">
                      <Badge variant={isDenied ? 'rose' : isEmergency ? 'amber' : 'emerald'}>
                        {tx.type}
                      </Badge>
                    </td>
                    <td className="py-2.5 px-3 text-cyan-300 font-semibold">
                      <span className="flex items-center gap-1">
                        {tx.txHash.slice(0, 16)}...
                        <button
                          onClick={() => handleCopy(tx.txHash)}
                          className="text-slate-500 hover:text-slate-300"
                        >
                          {copiedText === tx.txHash ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 truncate max-w-[150px]">
                      {tx.actorDid}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300 font-sans max-w-[280px] truncate">
                      {tx.details}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500 text-[10px]">
                      {new Date(tx.timestamp).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => setSelectedTx(tx)}
                        className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[11px]"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* BLOCK DETAILS MODAL */}
      {selectedBlock && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedBlock(null)}
          title={`Block #${selectedBlock.blockNumber} Details`}
          subtitle={`Sealed by ${selectedBlock.validator}`}
          maxWidth="2xl"
        >
          <div className="space-y-4 text-xs font-mono">
            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex justify-between border-b border-slate-900 pb-1">
                <span className="text-slate-500">Block Number:</span>
                <span className="text-emerald-400 font-bold">#{selectedBlock.blockNumber}</span>
              </div>
              <div className="flex justify-between border-b border-slate-900 pb-1">
                <span className="text-slate-500">Current Hash:</span>
                <span className="text-cyan-300 text-[11px] break-all max-w-sm">
                  {selectedBlock.currentHash}
                </span>
              </div>
              <div className="flex justify-between border-b border-slate-900 pb-1">
                <span className="text-slate-500">Previous Hash:</span>
                <span className="text-slate-400 text-[11px] break-all max-w-sm">
                  {selectedBlock.previousHash}
                </span>
              </div>
              <div className="flex justify-between border-b border-slate-900 pb-1">
                <span className="text-slate-500">Merkle Root:</span>
                <span className="text-emerald-300 text-[11px] break-all max-w-sm">
                  {selectedBlock.merkleRoot}
                </span>
              </div>
              <div className="flex justify-between border-b border-slate-900 pb-1">
                <span className="text-slate-500">Nonce:</span>
                <span className="text-slate-300">{selectedBlock.nonce}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Timestamp:</span>
                <span className="text-slate-300">
                  {new Date(selectedBlock.timestamp).toUTCString()}
                </span>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-200 font-sans mb-2">
                Transactions in Block ({selectedBlock.transactions.length})
              </h4>
              <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar">
                {selectedBlock.transactions.map((t) => (
                  <div
                    key={t.id}
                    className="p-2.5 rounded bg-slate-950 border border-slate-800 text-[11px] flex justify-between items-center"
                  >
                    <div>
                      <Badge variant="cyan">{t.type}</Badge>
                      <span className="text-slate-300 ml-2 font-sans">{t.details}</span>
                    </div>
                    <span className="text-slate-500 text-[10px]">{t.txHash.slice(0, 12)}...</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedBlock(null)}
                className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-sans"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* TX DETAILS MODAL */}
      {selectedTx && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedTx(null)}
          title="Blockchain Transaction Record"
          subtitle={`Type: ${selectedTx.type}`}
          maxWidth="lg"
        >
          <div className="space-y-3 text-xs font-mono">
            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
              <div>
                <span className="text-slate-500 block text-[10px]">TRANSACTION HASH</span>
                <span className="text-cyan-300 text-xs font-semibold break-all">
                  {selectedTx.txHash}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">ACTOR DID</span>
                <span className="text-emerald-400 text-xs">{selectedTx.actorDid}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">EVENT DESCRIPTION</span>
                <span className="text-slate-200 text-xs font-sans">{selectedTx.details}</span>
              </div>
              <div className="flex justify-between border-t border-slate-900 pt-2 text-[10px]">
                <span className="text-slate-500">Status: {selectedTx.status}</span>
                <span className="text-slate-400">{new Date(selectedTx.timestamp).toUTCString()}</span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedTx(null)}
                className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-sans"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
