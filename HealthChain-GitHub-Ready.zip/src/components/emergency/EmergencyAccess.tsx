import React, { useState, useEffect } from 'react';
import { User, Permission } from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { authorizationService } from '../../services/authorizationService';
import { Badge } from '../common/Badge';
import {
  Flame,
  AlertTriangle,
  Clock,
  ShieldAlert,
  CheckCircle2,
  Lock,
  UserX,
  FileWarning,
} from 'lucide-react';

interface EmergencyAccessProps {
  currentUser: User;
  onNavigateTab: (tab: string) => void;
}

export const EmergencyAccess: React.FC<EmergencyAccessProps> = ({
  currentUser,
  onNavigateTab,
}) => {
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [patientDid, setPatientDid] = useState('did:health:patient:001');
  const [patientName, setPatientName] = useState('Sarah Jenkins');
  const [doctorDid, setDoctorDid] = useState(
    currentUser.role === 'doctor' ? currentUser.did : 'did:health:doctor:001'
  );
  const [doctorName, setDoctorName] = useState(
    currentUser.role === 'doctor' ? currentUser.name : 'Dr. Marcus Vance'
  );
  const [emergencyReason, setEmergencyReason] = useState(
    'Acute cardiac distress / syncope presentation requiring immediate telemetry and medication reconciliation'
  );
  const [durationHours, setDurationHours] = useState(2);
  const [acknowledged, setAcknowledged] = useState(false);

  useEffect(() => {
    const update = () => {
      const allPerms = storageService.getPermissions();
      setPermissions(allPerms.filter((p) => p.isEmergency));
    };
    update();
    return subscribeToStorage(update);
  }, []);

  const handleTriggerEmergency = (e: React.FormEvent) => {
    e.preventDefault();
    if (!acknowledged) return;

    authorizationService.grantEmergencyAccess({
      doctorDid,
      doctorName,
      patientDid,
      patientName,
      institution: currentUser.institution || 'CityCare Hospital',
      emergencyReason,
      durationHours: Number(durationHours),
    });

    setAcknowledged(false);
  };

  const handleRevoke = (id: string) => {
    authorizationService.revokePermission(id);
  };

  const activeEmergencies = permissions.filter((p) => p.status === 'ACTIVE');

  return (
    <div id="emergency-access-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner with Severe Clinical Warning */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-rose-950/90 via-slate-900 to-slate-950 border border-rose-500/50 shadow-xl">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-lg bg-rose-900/60 border border-rose-500/40 text-rose-400 shrink-0">
            <Flame className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-rose-300">
                BREAK-GLASS PROTOCOL
              </span>
              <Badge variant="rose" dot>
                Mandatory Regulatory Audit
              </Badge>
            </div>
            <h2 className="text-xl font-bold text-slate-100 mt-1">
              Emergency Clinical Access Management
            </h2>
            <p className="text-xs text-rose-200/80 mt-1 font-medium leading-relaxed max-w-3xl">
              &quot;Emergency access should only be used when clinically necessary.&quot; Invoking the Break-Glass override temporarily bypasses standard patient consent to preserve human life. All actions trigger immediate real-time notifications to the patient, hospital cybersecurity officers, and an immutable cryptographic block entry.
            </p>
          </div>
        </div>
      </div>

      {/* Grid: Emergency Trigger Form & Active Emergencies */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" /> Invoke Break-Glass Access
            </h3>
            <span className="text-[10px] font-mono text-slate-400">Section 20 Compliance</span>
          </div>

          <form onSubmit={handleTriggerEmergency} className="space-y-3.5 text-xs font-sans">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Attending Physician</label>
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono flex items-center justify-between">
                <span>{doctorName}</span>
                <span className="text-cyan-300 text-[11px]">{doctorDid}</span>
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Target Patient</label>
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono flex items-center justify-between">
                <span>{patientName}</span>
                <span className="text-emerald-300 text-[11px]">{patientDid}</span>
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Clinical Justification & Emergency Reason
              </label>
              <textarea
                required
                rows={3}
                value={emergencyReason}
                onChange={(e) => setEmergencyReason(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-rose-500 font-mono text-xs"
                placeholder="State precise clinical indication (e.g. Unconscious patient in trauma bay, acute myocardial infarction)..."
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Emergency Duration (Hard Expiration)
              </label>
              <select
                value={durationHours}
                onChange={(e) => setDurationHours(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-rose-500 font-mono text-xs"
              >
                <option value={1}>1 Hour (Immediate Resuscitation)</option>
                <option value={2}>2 Hours (Acute Stabilization Window)</option>
                <option value={4}>4 Hours (Trauma / OR Procedure)</option>
                <option value={8}>8 Hours (ICU Shift Handover)</option>
              </select>
            </div>

            <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-500/30 text-rose-200 text-[11px] space-y-2 font-mono">
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  id="checkbox-emergency-ack"
                  checked={acknowledged}
                  onChange={(e) => setAcknowledged(e.target.checked)}
                  className="mt-0.5 rounded border-rose-500 text-rose-600 focus:ring-rose-500"
                />
                <span className="leading-relaxed">
                  I certify under clinical penalty that this break-glass access is critically necessary for immediate patient survival. I acknowledge that this event is immutably timestamped on the consortium blockchain.
                </span>
              </label>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                id="btn-trigger-emergency"
                disabled={!acknowledged}
                className="w-full py-2.5 px-4 rounded-lg bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-950/50 transition-all"
              >
                <Flame className="w-4 h-4 text-slate-950" />
                <span>AUTHORIZE BREAK-GLASS EMERGENCY ACCESS</span>
              </button>
            </div>
          </form>
        </div>

        {/* Active Emergency Permissions & Countdown */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" /> Active Emergency Tokens
            </h3>
            <Badge variant={activeEmergencies.length > 0 ? 'rose' : 'slate'} dot={activeEmergencies.length > 0}>
              {activeEmergencies.length} Active Override
            </Badge>
          </div>

          {activeEmergencies.length === 0 ? (
            <div className="py-12 text-center text-xs font-mono text-slate-400 space-y-2">
              <ShieldAlert className="w-8 h-8 text-slate-600 mx-auto" />
              <p>No active break-glass emergency overrides.</p>
              <p className="text-[11px] text-slate-500">
                All patient data remains locked under regular dynamic consent policy.
              </p>
            </div>
          ) : (
            <div className="space-y-3 font-mono text-xs">
              {activeEmergencies.map((perm) => (
                <div
                  key={perm.id}
                  className="p-4 rounded-lg bg-slate-950 border border-rose-500/40 space-y-2.5 shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-rose-400 font-bold flex items-center gap-1.5">
                      <Flame className="w-4 h-4" /> BREAK-GLASS GRANTED
                    </span>
                    <span className="text-[10px] text-slate-400">ID: {perm.id}</span>
                  </div>

                  <div className="text-slate-200">
                    Physician: <span className="text-cyan-300 font-semibold">{perm.doctorName}</span>
                  </div>

                  <div className="text-slate-400 text-[11px]">
                    Authorized Scope: {perm.recordTypes.join(', ')}
                  </div>

                  <div className="p-2 rounded bg-slate-900 text-slate-300 text-[11px] font-sans">
                    Expires At: {new Date(perm.expiryDate).toLocaleTimeString()} (
                    {new Date(perm.expiryDate).toLocaleDateString()})
                  </div>

                  <div className="text-[10px] text-slate-400 truncate">
                    Audit Tx Hash: {perm.transactionHash}
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <button
                      onClick={() => onNavigateTab('ehr')}
                      className="text-xs text-cyan-400 hover:underline font-mono"
                    >
                      View Patient EHR Now &rarr;
                    </button>
                    <button
                      id={`btn-revoke-emergency-${perm.id}`}
                      onClick={() => handleRevoke(perm.id)}
                      className="px-3 py-1 rounded bg-slate-800 hover:bg-rose-900 text-rose-300 border border-rose-500/30 text-xs font-semibold"
                    >
                      Terminate Early
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Historical Audits */}
          <div className="pt-3 border-t border-slate-800">
            <h4 className="text-xs font-semibold text-slate-300 font-mono mb-2">
              Recent Emergency Audit Log
            </h4>
            <div className="space-y-1.5 text-[11px] font-mono text-slate-400">
              {permissions.map((p) => (
                <div
                  key={p.id}
                  className="p-2 rounded bg-slate-950 flex items-center justify-between border border-slate-900"
                >
                  <span className="truncate max-w-[200px]">{p.doctorName} override</span>
                  <Badge variant={p.status === 'ACTIVE' ? 'rose' : 'slate'}>{p.status}</Badge>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
