import React, { useState, useEffect } from 'react';
import { User, NotificationItem } from '../../types';
import { storageService, subscribeToStorage, INITIAL_USERS } from '../../services/storageService';
import { blockchainService } from '../../services/blockchainService';
import {
  Bell,
  ShieldCheck,
  UserCheck,
  Check,
  Play,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface HeaderProps {
  currentUser: User;
  onSwitchUser: (user: User) => void;
  onOpenDemoGuide: () => void;
  onOpenResetModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onSwitchUser,
  onOpenDemoGuide,
  onOpenResetModal,
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [integrityStatus, setIntegrityStatus] = useState<boolean>(true);

  useEffect(() => {
    const update = () => {
      setNotifications(storageService.getNotifications());
      const res = blockchainService.verifyChainIntegrity();
      setIntegrityStatus(res.isValid);
    };
    update();
    return subscribeToStorage(update);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleMarkAllRead = () => {
    storageService.markAllNotificationsRead();
  };

  return (
    <header
      id="app-header"
      className="h-16 bg-slate-900/95 border-b border-slate-800/90 px-5 flex items-center justify-between z-20 select-none"
    >
      {/* Title & Subtitle */}
      <div className="flex items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-bold text-slate-100 tracking-tight">HealthChain</h1>
            <span className="hidden md:inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-emerald-950/90 text-emerald-300 border border-emerald-500/40">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              Verified Multi-Institutional Ledger
            </span>
          </div>
          <p className="text-[11px] text-slate-400 truncate max-w-md hidden sm:block">
            Decentralized Healthcare DID & Dynamic Access Management
          </p>
        </div>
      </div>

      {/* Center / Right controls */}
      <div className="flex items-center gap-2.5">
        {/* Quick Role Switcher Bar (Crucial for Demo Demonstration) */}
        <div className="hidden lg:flex items-center bg-slate-950/80 p-1 rounded-lg border border-slate-800">
          <span className="text-[10px] font-mono text-slate-400 px-2 flex items-center gap-1">
            <UserCheck className="w-3 h-3 text-cyan-400" /> Role:
          </span>
          {INITIAL_USERS.map((user) => {
            const isActive = currentUser.id === user.id;
            return (
              <button
                key={user.id}
                id={`quick-switch-${user.role}`}
                onClick={() => onSwitchUser(user)}
                className={`px-2.5 py-1 rounded text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-slate-800 text-emerald-300 shadow-sm border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
                title={`Switch session to ${user.name} (${user.role})`}
              >
                {user.role === 'patient'
                  ? 'Sarah (Patient)'
                  : user.role === 'doctor'
                  ? 'Dr. Vance (Doctor)'
                  : 'Admin'}
              </button>
            );
          })}
        </div>

        {/* Demo Guide Button */}
        <button
          id="btn-header-demo-guide"
          onClick={onOpenDemoGuide}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-medium transition-all"
        >
          <Play className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
          <span className="hidden sm:inline">13-Step Demo Guide</span>
          <span className="sm:hidden">Demo</span>
        </button>

        {/* Reset State Button */}
        <button
          id="btn-header-reset-demo"
          onClick={onOpenResetModal}
          title="Reset all fictional records, DIDs and transactions"
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        {/* Notifications Dropdown Button */}
        <div className="relative">
          <button
            id="btn-notifications"
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800 transition-colors"
            title="System Audit & Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 text-[9px] font-bold text-slate-950 flex items-center justify-center animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications Popover */}
          {showNotifications && (
            <div
              id="notifications-popover"
              className="absolute right-0 mt-2 w-80 sm:w-96 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 overflow-hidden"
            >
              <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-slate-950">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-semibold text-slate-200">System Activity</span>
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={handleMarkAllRead}
                    className="text-[10px] text-slate-400 hover:text-emerald-400 flex items-center gap-1"
                  >
                    <Check className="w-3 h-3" /> Mark all read
                  </button>
                )}
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/60 custom-scrollbar">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">
                    No active notifications.
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      className={`p-3 text-xs transition-colors ${
                        n.read ? 'opacity-70 bg-slate-900/50' : 'bg-slate-800/40'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-200">{n.title}</span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {new Date(n.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <p className="text-slate-300 mt-1 leading-relaxed">{n.message}</p>
                    </div>
                  ))
                )}
              </div>

              <div className="p-2.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                <span>Ledger: {integrityStatus ? '✓ Verified' : '⚠ Syncing'}</span>
                <span>Hyperledger Fabric Concept</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
