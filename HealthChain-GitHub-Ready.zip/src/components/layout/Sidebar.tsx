import React from 'react';
import { User } from '../../types';
import {
  LayoutDashboard,
  Fingerprint,
  FileText,
  KeyRound,
  Flame,
  Activity,
  Blocks,
  ShieldAlert,
  Building2,
  Presentation,
  BookOpen,
  Settings,
  LogOut,
  ShieldCheck,
} from 'lucide-react';

interface SidebarProps {
  currentUser: User;
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onLogout: () => void;
  onOpenDemoGuide: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentUser,
  currentTab,
  onSelectTab,
  onLogout,
  onOpenDemoGuide,
}) => {
  const menuItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: currentUser.role.toUpperCase(),
    },
    {
      id: 'did',
      label: 'Decentralized ID (DID)',
      icon: Fingerprint,
    },
    {
      id: 'ehr',
      label: 'Electronic Health Records',
      icon: FileText,
    },
    {
      id: 'access',
      label: 'Access & Consent Control',
      icon: KeyRound,
    },
    {
      id: 'emergency',
      label: 'Emergency "Break-Glass"',
      icon: Flame,
      alert: true,
    },
    {
      id: 'iomt',
      label: 'IoMT Telemetry & Vitals',
      icon: Activity,
    },
    {
      id: 'blockchain',
      label: 'Blockchain Ledger',
      icon: Blocks,
    },
    {
      id: 'security',
      label: 'Cybersecurity Audit',
      icon: ShieldAlert,
    },
    {
      id: 'institutions',
      label: 'Multi-Institutions',
      icon: Building2,
    },
    {
      id: 'about',
      label: 'About Project & Novelty',
      icon: BookOpen,
    },
    {
      id: 'settings',
      label: 'Settings & Reset',
      icon: Settings,
    },
  ];

  return (
    <aside
      id="main-sidebar"
      className="w-64 bg-slate-950/95 border-r border-slate-800/80 flex flex-col shrink-0 select-none z-30"
    >
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-500/20 via-cyan-500/20 to-indigo-500/20 border border-emerald-500/40 flex items-center justify-center shadow-lg shadow-emerald-950/50">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold tracking-tight text-slate-100 text-base">HealthChain</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                v2.4
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono">DID & Access Mgmt</p>
          </div>
        </div>

        {/* Demo Guide Launch Button */}
        <button
          id="btn-open-demo-guide-sidebar"
          onClick={onOpenDemoGuide}
          className="mt-3.5 w-full flex items-center justify-between px-3 py-2 rounded-lg bg-gradient-to-r from-emerald-950/70 to-cyan-950/70 border border-emerald-500/40 text-emerald-200 hover:border-emerald-400 hover:text-emerald-100 transition-all text-xs font-medium shadow-sm group"
        >
          <div className="flex items-center gap-2">
            <Presentation className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
            <span>13-Step Demo Guide</span>
          </div>
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
            Live Tour
          </span>
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-1 custom-scrollbar">
        <div className="px-2 py-1 text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-400">
          Core Architecture
        </div>
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-slate-800/90 text-emerald-300 border border-emerald-500/30 shadow-sm shadow-emerald-950/50'
                  : 'text-slate-300 hover:text-slate-100 hover:bg-slate-900/80 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive
                      ? 'text-emerald-400'
                      : item.alert
                      ? 'text-amber-400'
                      : 'text-slate-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  {item.badge}
                </span>
              )}
              {item.alert && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
              )}
            </button>
          );
        })}
      </nav>

      {/* User Info & Logout */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950">
        <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-slate-200 truncate">{currentUser.name}</p>
            <p className="text-[10px] text-slate-400 font-mono truncate">{currentUser.did}</p>
          </div>
          <button
            id="btn-sidebar-logout"
            onClick={onLogout}
            title="Switch User / Logout"
            className="p-1.5 rounded-md text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
