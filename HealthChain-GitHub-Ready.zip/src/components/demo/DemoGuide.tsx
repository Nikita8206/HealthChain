import React, { useState } from 'react';
import { Badge } from '../common/Badge';
import {
  Compass,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Play,
  Layers,
  Sparkles,
  ExternalLink,
} from 'lucide-react';

interface DemoGuideProps {
  onNavigateTab: (tab: string) => void;
  onSwitchRole: (role: 'patient' | 'doctor' | 'admin') => void;
}

interface Step {
  stepNumber: number;
  title: string;
  role: 'patient' | 'doctor' | 'admin';
  targetTab: string;
  objective: string;
  instructions: string[];
  expectedOutcome: string;
}

export const DemoGuide: React.FC<DemoGuideProps> = ({ onNavigateTab, onSwitchRole }) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  const steps: Step[] = [
    {
      stepNumber: 1,
      title: 'Decentralized Identity (DID) Generation & Verification',
      role: 'admin',
      targetTab: 'did',
      objective: 'Demonstrate self-sovereign identity creation according to the W3C DID specification.',
      instructions: [
        'Navigate to the DID Management view.',
        'Click "Generate DID" to create a new decentralized identifier (e.g. for an IoMT Device or Doctor).',
        'Click "Verify DID" on an unverified identity and observe the verified badge.',
        'Click "View DID Document" to inspect the cryptographic JSON-LD document.',
      ],
      expectedOutcome: 'New DID is minted with an Ed25519 public key and verified on the consortium ledger.',
    },
    {
      stepNumber: 2,
      title: 'Patient Dashboard & Consent Control Center',
      role: 'patient',
      targetTab: 'patient-dashboard',
      objective: 'Showcase patient data sovereignty and real-time medical IoT vitals.',
      instructions: [
        'Switch to the Patient role (Sarah Jenkins).',
        'Review the personalized patient dashboard, decentralized DID badge, and connected hospital nodes.',
        'Examine the live IoMT vitals stream (Heart Rate, Blood Pressure, Glucose).',
      ],
      expectedOutcome: 'Patient has complete transparency over their active identity, live devices, and pending doctor requests.',
    },
    {
      stepNumber: 3,
      title: 'Doctor Patient Directory & Access Testing',
      role: 'doctor',
      targetTab: 'doctor-dashboard',
      objective: 'Demonstrate that physicians do NOT have automatic access to all patient records.',
      instructions: [
        'Switch to the Doctor role (Dr. Marcus Vance).',
        'Navigate to the Doctor Dashboard.',
        'Under Patient Directory, click "Query Record" on Sarah Jenkins\'s Diagnosis record.',
      ],
      expectedOutcome: 'Zero-trust authorization dynamically checks permissions. If permitted, record is revealed; otherwise access denied.',
    },
    {
      stepNumber: 4,
      title: 'Submitting a Dynamic Access Request',
      role: 'doctor',
      targetTab: 'doctor-dashboard',
      objective: 'Simulate doctor submitting a fine-grained, time-bounded request.',
      instructions: [
        'In the Doctor Dashboard, click "Request Patient Access".',
        'Select requested record types (e.g., Diagnosis, Prescription).',
        'Set duration (e.g., 24 hours) and clinical purpose.',
        'Click "Send Access Request".',
      ],
      expectedOutcome: 'A new PENDING request is anchored on the blockchain and queued for patient consent.',
    },
    {
      stepNumber: 5,
      title: 'Patient Dynamic Consent Approval',
      role: 'patient',
      targetTab: 'access',
      objective: 'Demonstrate patient-sovereign consent approval.',
      instructions: [
        'Switch role back to Patient (Sarah Jenkins).',
        'Navigate to the Access & Consent tab.',
        'Locate the pending request from Dr. Marcus Vance.',
        'Click "Approve Access".',
      ],
      expectedOutcome: 'Status transitions to APPROVED. A cryptographic permission grant and blockchain transaction hash are generated.',
    },
    {
      stepNumber: 6,
      title: 'Verified EHR Decryption & Inspection',
      role: 'doctor',
      targetTab: 'ehr',
      objective: 'Verify that the approved doctor can now inspect the authorized records.',
      instructions: [
        'Switch role to Doctor (Dr. Marcus Vance).',
        'Navigate to the EHR Records Vault.',
        'Click "Inspect" on the Diagnosis or Prescription record.',
      ],
      expectedOutcome: 'The dynamic authorization engine evaluates the active permission and decrypts the clinical record.',
    },
    {
      stepNumber: 7,
      title: 'Record-Level Restriction & Access Denied (Section 12)',
      role: 'doctor',
      targetTab: 'ehr',
      objective: 'Demonstrate that unconsented records (e.g. Genetic Data) remain strictly forbidden.',
      instructions: [
        'While in the Doctor role, click on the "Genetic Data" record (or filter by Genetic Data).',
        'Click "Inspect" on the Genetic Data record.',
      ],
      expectedOutcome: 'Red "ACCESS DENIED" modal appears with policy reason: "The requested record is not included in the current permission." A security audit event is logged!',
    },
    {
      stepNumber: 8,
      title: 'Real-Time Patient Consent Revocation',
      role: 'patient',
      targetTab: 'access',
      objective: 'Showcase that patients can revoke doctor permissions at any moment.',
      instructions: [
        'Switch role back to Patient (Sarah Jenkins).',
        'Go to Access & Consent -> "Active Grants & Permissions".',
        'Click "Revoke Access" on the doctor\'s active permission.',
      ],
      expectedOutcome: 'The permission is immediately deactivated and a revocation block transaction is written to the ledger.',
    },
    {
      stepNumber: 9,
      title: 'Break-Glass Emergency Protocol Override (Section 20)',
      role: 'doctor',
      targetTab: 'emergency',
      objective: 'Demonstrate emergency clinical access when patient is incapacitated.',
      instructions: [
        'Switch role to Doctor.',
        'Navigate to the Emergency Access tab.',
        'Check the regulatory warning and enter emergency justification.',
        'Click "AUTHORIZE BREAK-GLASS EMERGENCY ACCESS".',
      ],
      expectedOutcome: 'A temporary emergency token is granted with a countdown timer, security sirens, and immediate patient notification.',
    },
    {
      stepNumber: 10,
      title: 'IoMT Medical Device Telemetry & Live Anomaly Injection (Section 14)',
      role: 'admin',
      targetTab: 'iomt',
      objective: 'Demonstrate live biometric streaming from IoMT devices and automatic anomaly flagging.',
      instructions: [
        'Navigate to the IoMT Devices & Mesh tab.',
        'Observe live updating charts for Heart Rate, Blood Pressure, Glucose, and SpO2.',
        'Click "Simulate Anomaly" to inject an acute biometric spike.',
      ],
      expectedOutcome: 'The metric turns flashing red, an anomaly warning is displayed, and an incident is logged to the blockchain.',
    },
    {
      stepNumber: 11,
      title: 'Multi-Institutional Cross-Hospital Handshake (Section 17-18)',
      role: 'admin',
      targetTab: 'institutions',
      objective: 'Demonstrate cross-hospital data sharing between CityCare, Sanjivani, Apollo, and Rural Clinics.',
      instructions: [
        'Navigate to the Multi-Institution tab.',
        'Review the consortium nodes and trust scores.',
        'Click "Cross-Institutional Access Test" to simulate Dr. Priya Sharma from Sanjivani querying CityCare.',
      ],
      expectedOutcome: 'Cross-institutional federated handshake succeeds and queues a cross-boundary consent transaction.',
    },
    {
      stepNumber: 12,
      title: 'Blockchain Ledger & Merkle Root Verification (Section 15)',
      role: 'admin',
      targetTab: 'blockchain',
      objective: 'Inspect the cryptographic sequence of blocks and verify immutability.',
      instructions: [
        'Navigate to the Blockchain Explorer tab.',
        'Click any block in the horizontal visual chain to inspect its header, Merkle root, and transactions.',
        'Click "Verify Chain Integrity".',
      ],
      expectedOutcome: 'Displays: "Blockchain Integrity: 100% Valid (All hashes match cryptographic sequence)".',
    },
    {
      stepNumber: 13,
      title: 'Cybersecurity Incident Center & Threat Matrix (Section 22)',
      role: 'admin',
      targetTab: 'security',
      objective: 'Review comprehensive cybersecurity audit logs and defense responses.',
      instructions: [
        'Navigate to the Cybersecurity tab.',
        'Review the 4 primary threat telemetry counters: EHR Denied, IoMT Anomalies, Emergency Overrides, and Unauthorized Access.',
        'Examine the Live Threat Incident Log.',
      ],
      expectedOutcome: 'Demonstrates robust defense in depth and complete auditability for academic project defense.',
    },
  ];

  const currentStep = steps[currentStepIndex];

  const handleExecuteStep = () => {
    onSwitchRole(currentStep.role);
    onNavigateTab(currentStep.targetTab);
  };

  return (
    <div id="demo-guide-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-emerald-400">
              ACADEMIC PRESENTATION CONTROLLER
            </span>
            <Badge variant="emerald" dot>
              13-Step Presentation Flow
            </Badge>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">
            Guided Demonstration & Faculty Evaluation Guide
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Step-by-step interactive script engineered specifically for final-year engineering project viva, external reviewer demonstrations, and academic defense.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentStepIndex(Math.max(0, currentStepIndex - 1))}
            disabled={currentStepIndex === 0}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-slate-300 font-semibold px-2">
            {currentStepIndex + 1} / {steps.length}
          </span>
          <button
            onClick={() => setCurrentStepIndex(Math.min(steps.length - 1, currentStepIndex + 1))}
            disabled={currentStepIndex === steps.length - 1}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Active Step Showcase Card */}
      <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-emerald-400">
                STEP {currentStep.stepNumber} OF 13
              </span>
              <Badge
                variant={
                  currentStep.role === 'patient'
                    ? 'emerald'
                    : currentStep.role === 'doctor'
                    ? 'cyan'
                    : 'indigo'
                }
              >
                Role: {currentStep.role.toUpperCase()}
              </Badge>
            </div>
            <h3 className="text-lg font-bold text-slate-100 mt-1">{currentStep.title}</h3>
          </div>

          <button
            id="btn-execute-demo-step"
            onClick={handleExecuteStep}
            className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs flex items-center gap-2 transition-all shadow-md shrink-0"
          >
            <Play className="w-4 h-4 fill-slate-950" />
            <span>Go to Step in App</span>
            <ExternalLink className="w-3.5 h-3.5 ml-1" />
          </button>
        </div>

        {/* Objective */}
        <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs">
          <span className="text-slate-500 block text-[10px]">DEMONSTRATION OBJECTIVE</span>
          <span className="text-emerald-300 font-medium font-sans text-xs mt-0.5 block">
            {currentStep.objective}
          </span>
        </div>

        {/* Instructions */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-slate-200 font-mono">ACTION STEPS TO PERFORM:</h4>
          <ol className="space-y-2 text-xs text-slate-300 font-sans pl-1">
            {currentStep.instructions.map((inst, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-cyan-300 font-mono text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                  {i + 1}
                </span>
                <span className="leading-relaxed">{inst}</span>
              </li>
            ))}
          </ol>
        </div>

        {/* Expected Outcome */}
        <div className="p-3.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs font-mono space-y-1">
          <span className="text-emerald-400 font-bold block flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" /> EXPECTED TECHNICAL OUTCOME
          </span>
          <p className="font-sans text-[11px] leading-relaxed text-emerald-300">
            {currentStep.expectedOutcome}
          </p>
        </div>
      </div>

      {/* Step Navigation Matrix (1 to 13 chips) */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800">
        <h4 className="text-xs font-semibold text-slate-300 font-mono mb-3">
          COMPLETE 13-STEP DEMO SEQUENCE
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {steps.map((s, idx) => (
            <button
              key={s.stepNumber}
              onClick={() => setCurrentStepIndex(idx)}
              className={`p-2.5 rounded-lg border text-left text-xs font-mono transition-all flex items-start gap-2 ${
                currentStepIndex === idx
                  ? 'bg-slate-800 border-emerald-500 text-emerald-300 shadow-sm'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <span className="font-bold text-slate-200 shrink-0">#{s.stepNumber}</span>
              <span className="font-sans line-clamp-1">{s.title}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
