import React, { useState, useEffect } from 'react';
import { Institution, User } from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { authorizationService } from '../../services/authorizationService';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';
import {
  Building2,
  Globe2,
  ShieldCheck,
  CheckCircle2,
  ArrowRightLeft,
  Server,
  Network,
  Users,
  Send,
  AlertCircle,
} from 'lucide-react';

interface MultiInstitutionProps {
  currentUser: User;
  onNavigateTab: (tab: string) => void;
}

export const MultiInstitution: React.FC<MultiInstitutionProps> = ({
  currentUser,
  onNavigateTab,
}) => {
  const [institutions, setInstitutions] = useState<Institution[]>([]);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);

  // Cross-Institutional Access Test State
  const [sourceInst, setSourceInst] = useState('Sanjivani Medical Center');
  const [targetInst, setTargetInst] = useState('CityCare Hospital');
  const [visitingDoctorName, setVisitingDoctorName] = useState('Dr. Priya Sharma');
  const [visitingDoctorDid, setVisitingDoctorDid] = useState('did:health:doctor:002');
  const [testResult, setTestResult] = useState<{
    show: boolean;
    success: boolean;
    message: string;
    details: string;
    txHash?: string;
  } | null>(null);

  useEffect(() => {
    const update = () => {
      setInstitutions(storageService.getInstitutions());
    };
    update();
    return subscribeToStorage(update);
  }, []);

  const handleRunFederatedTest = (e: React.FormEvent) => {
    e.preventDefault();

    // Submit a cross-institutional request
    const req = authorizationService.createAccessRequest({
      doctorDid: visitingDoctorDid,
      doctorName: visitingDoctorName,
      patientDid: 'did:health:patient:001',
      patientName: 'Sarah Jenkins',
      institution: sourceInst,
      requestedRecords: ['Diagnosis', 'Prescription', 'Treatment History'],
      purpose: 'Cross-institutional specialty referral consultation from Sanjivani Medical Center',
      accessDurationHours: 48,
    });

    setTestResult({
      show: true,
      success: true,
      message: 'Cross-Institutional Federated Request Dispatched',
      details: `Federated handshake authenticated: ${sourceInst} (Trust: 95%) successfully verified against ${targetInst} consortium node. Patient consent request queued on blockchain ledger.`,
      txHash: req.transactionHash,
    });

    setIsTestModalOpen(false);
  };

  return (
    <div id="multi-institution-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-cyan-400">
              FEDERATED TRUST NETWORK
            </span>
            <Badge variant="cyan" dot>
              Multi-Hospital Consortium Active
            </Badge>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">
            Multi-Institutional Consortium Federation
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Decentralized identity enables seamless health data interoperability between CityCare Hospital, Sanjivani Medical Center, Apollo Health Center, and Rural Clinics without siloed central servers.
          </p>
        </div>

        <button
          id="btn-open-cross-inst-test"
          onClick={() => setIsTestModalOpen(true)}
          className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-semibold flex items-center gap-2 transition-all shadow-md shrink-0"
        >
          <ArrowRightLeft className="w-4 h-4" />
          <span>Cross-Institutional Access Test</span>
        </button>
      </div>

      {/* Test Result Toast/Banner */}
      {testResult && testResult.show && (
        <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 font-mono text-xs flex items-start justify-between gap-3 shadow-lg">
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold flex items-center gap-2">
                <span>{testResult.message}</span>
                <Badge variant="emerald">Federated Handshake OK</Badge>
              </div>
              <p className="text-[11px] text-emerald-300 mt-1 leading-relaxed">
                {testResult.details}
              </p>
              {testResult.txHash && (
                <div className="text-[10px] text-slate-400 mt-1">
                  Blockchain Tx: {testResult.txHash}
                </div>
              )}
            </div>
          </div>
          <button
            onClick={() => setTestResult(null)}
            className="text-slate-400 hover:text-slate-200 text-xs"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Institution Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {institutions.map((inst) => (
          <div
            key={inst.id}
            id={`inst-card-${inst.id}`}
            className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4 hover:border-slate-700 transition-all shadow-sm"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-cyan-400">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-100 text-sm font-sans">{inst.name}</h3>
                  <span className="text-[11px] text-slate-400 font-mono">{inst.location}</span>
                </div>
              </div>

              <div className="text-right">
                <Badge variant={inst.status === 'ACTIVE' ? 'emerald' : 'cyan'} dot>
                  {inst.status === 'ACTIVE' ? 'Active Peer' : 'Federated Peer'}
                </Badge>
                <div className="text-[11px] font-mono text-emerald-400 mt-1 font-bold">
                  Trust: {inst.trustScore}%
                </div>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 font-mono text-xs space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">DID Registry Node:</span>
                <span className="text-cyan-300 font-medium">{inst.didRegistryNode}</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Consensus Role:</span>
                <span className="text-slate-300">PBFT Validator & Endorser</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Federated Members:</span>
                <span className="text-slate-200">
                  {inst.doctorsCount} Physicians • {inst.patientsCount} Patients
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1 text-xs font-mono text-slate-400">
              <span className="flex items-center gap-1.5 text-[11px]">
                <Network className="w-3.5 h-3.5 text-emerald-400" /> Peer P2P Link Established
              </span>
              <span className="text-[10px] text-slate-500">Node Latency: ~14ms</span>
            </div>
          </div>
        ))}
      </div>

      {/* Consortium Architecture Explainer */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3 font-mono text-xs">
        <h4 className="text-xs font-bold text-slate-200 font-sans flex items-center gap-2">
          <Server className="w-4 h-4 text-emerald-400" /> Multi-Institutional Zero-Knowledge Trust Architecture
        </h4>
        <p className="text-slate-400 font-sans text-xs leading-relaxed">
          In legacy systems, health records are locked in isolated EHR vendor silos. When a patient visits an external specialist (e.g. at Sanjivani Medical Center), the specialist cannot verify the patient&apos;s records from CityCare Hospital without cumbersome manual transfers or security risks. HealthChain solves this through cryptographic DIDs and decentralized access control:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-[11px]">
          <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-emerald-400 font-bold block">1. Decentralized Identity</span>
            <span className="text-slate-400 font-sans">
              Doctor and patient present W3C DIDs signed by consortium member nodes.
            </span>
          </div>
          <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-cyan-400 font-bold block">2. Smart Contract Consent</span>
            <span className="text-slate-400 font-sans">
              Access rules execute transparently without passing plaintext credentials to third parties.
            </span>
          </div>
          <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-indigo-400 font-bold block">3. Immutable Interoperability</span>
            <span className="text-slate-400 font-sans">
              All cross-institutional accesses leave an indelible cryptographic trail in the consortium blockchain.
            </span>
          </div>
        </div>
      </div>

      {/* CROSS-INSTITUTIONAL TEST MODAL */}
      <Modal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
        title="Cross-Institutional Access Test"
        subtitle="Simulate Dr. Priya Sharma (Sanjivani) querying patient records hosted at CityCare Hospital"
        maxWidth="lg"
      >
        <form onSubmit={handleRunFederatedTest} className="space-y-4 text-xs font-sans">
          <div className="p-3 rounded-lg bg-cyan-950/40 border border-cyan-500/30 text-cyan-200 text-xs font-mono space-y-1">
            <div className="font-bold flex items-center gap-1.5">
              <Globe2 className="w-4 h-4 text-cyan-400" /> Multi-Hospital Simulation Scenario:
            </div>
            <div>Source: {sourceInst} (External Specialty Node)</div>
            <div>Target: {targetInst} (Primary Vault)</div>
            <div>Visiting Physician: {visitingDoctorName} ({visitingDoctorDid})</div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Target Patient</label>
            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono flex items-center justify-between">
              <span>Sarah Jenkins</span>
              <span className="text-emerald-300 text-[11px]">did:health:patient:001</span>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Cross-Institutional Access Scope
            </label>
            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-emerald-300 font-mono text-xs">
              Diagnosis, Prescription, Treatment History
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Clinical Justification</label>
            <textarea
              readOnly
              rows={2}
              value="Cardiology referral consultation for secondary opinion regarding diabetic medication adjustment"
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono text-xs"
            />
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsTestModalOpen(false)}
              className="px-4 py-1.5 rounded-lg bg-slate-800 text-slate-300 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold flex items-center gap-1.5"
            >
              <Send className="w-4 h-4" /> Run Federated Request Test
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
