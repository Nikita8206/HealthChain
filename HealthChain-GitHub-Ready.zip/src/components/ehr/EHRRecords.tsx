import React, { useState, useEffect } from 'react';
import { User, EHRRecord, EHRRecordType, Permission } from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { ehrService } from '../../services/ehrService';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';
import {
  FileText,
  Lock,
  Unlock,
  ShieldCheck,
  ShieldAlert,
  AlertCircle,
  Eye,
  PlusCircle,
  Filter,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';

interface EHRRecordsProps {
  currentUser: User;
  onNavigateTab: (tab: string) => void;
}

export const EHRRecords: React.FC<EHRRecordsProps> = ({ currentUser, onNavigateTab }) => {
  const [records, setRecords] = useState<EHRRecord[]>([]);
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [permissions, setPermissions] = useState<Permission[]>([]);

  // Inspect / Authorization Modal state
  const [activeRecord, setActiveRecord] = useState<EHRRecord | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    const update = () => {
      setRecords(storageService.getEHRRecords());
      setPermissions(storageService.getPermissions());
    };
    update();
    return subscribeToStorage(update);
  }, []);

  const recordTypes: (EHRRecordType | 'ALL')[] = [
    'ALL',
    'Diagnosis',
    'Prescription',
    'Laboratory Report',
    'Allergy',
    'Treatment History',
    'Medical Notes',
    'Genetic Data',
  ];

  const filteredRecords = records.filter(
    (r) => selectedType === 'ALL' || r.recordType === selectedType
  );

  const handleInspect = (record: EHRRecord) => {
    // If viewing as patient or admin, full patient-sovereign access is allowed
    if (currentUser.role === 'patient' || currentUser.role === 'admin') {
      setActiveRecord(record);
      setAuthError(null);
      return;
    }

    // If viewing as doctor, dynamic access control MUST be verified!
    const res = ehrService.getRecordWithAuthorization({
      recordId: record.id,
      doctorDid: currentUser.did,
      doctorName: currentUser.name,
      institution: currentUser.institution,
    });

    if (res.success && res.record) {
      setActiveRecord(res.record);
      setAuthError(null);
    } else {
      setActiveRecord(record);
      setAuthError(res.reason);
    }
  };

  return (
    <div id="ehr-records-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-emerald-400">
              CROSS-INSTITUTIONAL EHR
            </span>
            <Badge variant="emerald" dot>
              Fine-Grained Attribute Access
            </Badge>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">
            Electronic Health Records (EHR) Vault
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Simulated patient electronic health records with record-level access restrictions. For example, a physician may be authorized to view standard Diagnosis records, but blocked from viewing sensitive Genetic Data without explicit patient consent.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => onNavigateTab('access')}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-mono font-medium border border-slate-700 transition-colors"
          >
            Manage Consents &rarr;
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
        <Filter className="w-4 h-4 text-slate-400 shrink-0 ml-1" />
        {recordTypes.map((type) => (
          <button
            key={type}
            id={`filter-type-${type}`}
            onClick={() => setSelectedType(type)}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-all ${
              selectedType === type
                ? 'bg-emerald-600 text-slate-950 font-bold shadow-sm'
                : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {type}
          </button>
        ))}
      </div>

      {/* Records Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRecords.map((record) => {
          const isRestricted = record.recordType === 'Genetic Data';
          const isDoctor = currentUser.role === 'doctor';
          const hasDoctorConsent = permissions.some(
            (p) =>
              p.doctorDid === currentUser.did &&
              p.patientDid === record.patientDid &&
              p.status === 'ACTIVE' &&
              p.recordTypes.includes(record.recordType)
          );

          return (
            <div
              key={record.id}
              id={`ehr-item-${record.id}`}
              className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/90 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-indigo-300">
                    {record.recordType}
                  </span>
                  <Badge
                    variant={
                      record.accessLevel === 'Restricted'
                        ? 'rose'
                        : record.accessLevel === 'Confidential'
                        ? 'amber'
                        : 'emerald'
                    }
                  >
                    {record.accessLevel}
                  </Badge>
                </div>

                <h3 className="text-sm font-bold text-slate-100 mt-2.5 line-clamp-1">
                  {record.title}
                </h3>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                  {record.clinicalNotes}
                </p>

                <div className="mt-3 p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 text-[11px] font-mono space-y-1">
                  <div className="text-slate-400">
                    Patient: <span className="text-slate-200">{record.patientName}</span>
                  </div>
                  <div className="text-slate-400">
                    Hospital: <span className="text-cyan-300">{record.hospital}</span>
                  </div>
                  <div className="text-slate-400">
                    Created: <span className="text-slate-300">{record.createdDate}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400">
                  {isDoctor ? (
                    hasDoctorConsent ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <Unlock className="w-3 h-3" /> Consent Active
                      </span>
                    ) : (
                      <span className="text-rose-400 flex items-center gap-1">
                        <Lock className="w-3 h-3" /> Requires Consent
                      </span>
                    )
                  ) : (
                    <span className="text-cyan-400 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Sovereign Vault
                    </span>
                  )}
                </div>

                <button
                  id={`btn-view-ehr-${record.id}`}
                  onClick={() => handleInspect(record)}
                  className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-mono font-medium flex items-center gap-1 border border-slate-700 transition-colors"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Inspect</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* RECORD DETAILS & AUTHORIZATION MODAL */}
      {activeRecord && (
        <Modal
          isOpen={true}
          onClose={() => {
            setActiveRecord(null);
            setAuthError(null);
          }}
          title={authError ? 'ACCESS DENIED' : activeRecord.title}
          subtitle={
            authError
              ? 'Dynamic Zero Trust Access Enforcement'
              : `Record ID: ${activeRecord.id} • ${activeRecord.hospital}`
          }
          maxWidth="lg"
        >
          {authError ? (
            /* ACCESS DENIED VIEW (Section 12 requirement) */
            <div className="space-y-4 font-mono text-xs">
              <div className="p-4 rounded-lg bg-rose-950/80 border border-rose-500/50 text-rose-200 flex items-start gap-3">
                <AlertCircle className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-rose-300">ACCESS DENIED</h4>
                  <p className="mt-1 text-xs leading-relaxed">{authError}</p>
                </div>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 space-y-2">
                <div className="text-emerald-400 font-semibold font-sans">
                  Dynamic Authorization Policy:
                </div>
                <p className="font-sans text-[11px] leading-relaxed text-slate-400">
                  The requesting physician [Dr. Marcus Vance] does not possess an active patient consent grant from Sarah Jenkins for the [{activeRecord.recordType}] scope. An immutable security audit transaction has been appended to the blockchain ledger.
                </p>
                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => {
                      setActiveRecord(null);
                      setAuthError(null);
                      onNavigateTab('access');
                    }}
                    className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-sans font-semibold text-xs transition-colors"
                  >
                    Request Patient Consent
                  </button>
                  <button
                    onClick={() => {
                      setActiveRecord(null);
                      setAuthError(null);
                      onNavigateTab('emergency');
                    }}
                    className="px-3 py-1.5 rounded bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-500/40 font-sans font-semibold text-xs transition-colors"
                  >
                    Break-Glass Emergency Protocol
                  </button>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => {
                    setActiveRecord(null);
                    setAuthError(null);
                  }}
                  className="px-4 py-1.5 rounded bg-slate-800 text-slate-200 font-sans text-xs"
                >
                  Close
                </button>
              </div>
            </div>
          ) : (
            /* ACCESS GRANTED: DECRYPTED CLINICAL RECORD */
            <div className="space-y-4 text-xs font-mono">
              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ACCESS GRANTED: Verified by Dynamic Access Engine
                </span>
                <Badge variant="emerald">{activeRecord.accessLevel}</Badge>
              </div>

              {/* Data Table */}
              <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
                <div className="text-[10px] uppercase text-slate-400 font-semibold border-b border-slate-800 pb-1">
                  Structured Clinical Indicators
                </div>
                {Object.entries(activeRecord.data).map(([key, val]) => (
                  <div key={key} className="flex justify-between border-b border-slate-900 pb-1 pt-0.5">
                    <span className="text-slate-400">{key}:</span>
                    <span className="text-emerald-300 font-medium text-right max-w-xs break-words">
                      {String(val)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Notes */}
              <div>
                <span className="text-slate-400 block text-xs font-sans mb-1 font-medium">
                  Physician & Clinical Observations:
                </span>
                <p className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-sans text-xs leading-relaxed">
                  {activeRecord.clinicalNotes}
                </p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setActiveRecord(null)}
                  className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-sans text-xs font-medium"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
};
