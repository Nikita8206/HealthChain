import React from 'react';
import { Badge } from '../common/Badge';
import {
  BookOpen,
  ShieldCheck,
  Cpu,
  Layers,
  Award,
  CheckCircle2,
  FileCode2,
  GitBranch,
  Building2,
  Activity,
  Flame,
  Fingerprint,
  Users,
  User,
  GraduationCap,
} from 'lucide-react';

export const AboutProject: React.FC = () => {
  return (
    <div id="about-project-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Hero Presentation Card */}
      <div className="p-6 rounded-xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="cyan" dot>
            Final-Year Engineering Capstone Project
          </Badge>
          <Badge variant="indigo">
            Academic Project
          </Badge>
          <Badge variant="emerald">Academic Prototype v1.0</Badge>
          <Badge variant="slate">Department of Computer Science & Engineering</Badge>
        </div>

        <div>
          <h1 className="text-xl md:text-2xl font-black text-slate-100 tracking-tight leading-snug">
            Blockchain-Based Decentralized Identity and Dynamic Access Management System for
            Multi-Institutional Smart Healthcare and IoMT
          </h1>
          <p className="text-sm font-mono text-emerald-400 mt-2 font-semibold">
            System Codename: HealthChain
          </p>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed max-w-4xl font-sans">
          An academic functional prototype demonstrating Self-Sovereign Identity (SSI), W3C Decentralized Identifiers (DIDs), dynamic attribute-based access control (ABAC), multi-institution workflows, and an auditable blockchain-inspired ledger for healthcare. Blockchain, cryptographic verification, and IoMT telemetry are simulated for academic demonstration.
        </p>
      </div>

      {/* Project Team / Developed By Section */}
      <div id="project-team-section" className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-400" />
            <h2 className="text-sm font-bold text-slate-100 font-sans tracking-wide uppercase">
              Project Team / Developed By
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="indigo" dot>
              Academic Project
            </Badge>
            <Badge variant="cyan">
              Sanjivani University
            </Badge>
          </div>
        </div>

        {/* Project Title Card */}
        <div className="p-4 rounded-lg bg-slate-950 border border-slate-800/90 space-y-1">
          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">
            PROJECT TITLE
          </span>
          <p className="text-sm font-semibold text-slate-200 font-sans leading-snug">
            Blockchain-Based Decentralized Identity and Dynamic Access Management System for Multi-Institutional Smart Healthcare and IoMT
          </p>
        </div>

        {/* Team Details Grid: Developed By & Project Guide */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Developed By */}
          <div className="p-4 rounded-lg bg-slate-950 border border-emerald-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" /> DEVELOPED BY
              </span>
              <Badge variant="emerald">Project Author</Badge>
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-100 font-sans">
                Nikita Nawale
              </h3>
              <p className="text-xs font-mono text-emerald-300 mt-1">
                B.Tech – Computer Science Engineering (Cybersecurity)
              </p>
            </div>

            <div className="pt-2 border-t border-slate-900 flex items-center gap-2 text-xs font-mono text-slate-400">
              <Building2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span>Sanjivani University, Kopargaon</span>
            </div>
          </div>

          {/* Project Guide */}
          <div className="p-4 rounded-lg bg-slate-950 border border-cyan-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5" /> PROJECT GUIDE
              </span>
              <Badge variant="cyan">Faculty Guide</Badge>
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-100 font-sans">
                Mr. Sudhanshu Verma
              </h3>
              <p className="text-xs font-mono text-cyan-300 mt-1">
                Faculty Supervisor
              </p>
            </div>

            <div className="pt-2 border-t border-slate-900 flex items-center gap-2 text-xs font-mono text-slate-400">
              <Building2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span>Sanjivani University, Kopargaon</span>
            </div>
          </div>
        </div>
      </div>

      {/* Problem vs Proposed Solution Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Problem Statement */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-rose-500/30 space-y-3">
          <div className="flex items-center gap-2 text-rose-400 font-bold font-mono text-xs">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            PROBLEM STATEMENT
          </div>
          <h3 className="text-sm font-bold text-slate-100 font-sans">
            Healthcare Silos, Identity Theft & Fragile Consent
          </h3>
          <ul className="space-y-2 text-xs text-slate-300 font-sans leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="text-rose-400 font-bold font-mono">•</span>
              <span>
                <strong>Data Fragmentation:</strong> Hospital EHR systems exist in incompatible silos, making cross-hospital referrals cumbersome and error-prone.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400 font-bold font-mono">•</span>
              <span>
                <strong>Centralized Vulnerabilities:</strong> Centralized identity databases represent single points of failure susceptible to ransomware and large-scale credential leaks.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400 font-bold font-mono">•</span>
              <span>
                <strong>Static & Coarse-Grained Access:</strong> Traditional systems offer all-or-nothing consent. Doctors often receive unfettered access to sensitive records (e.g. psychiatric or genetic data) without active patient approval.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400 font-bold font-mono">•</span>
              <span>
                <strong>Insecure IoMT Integration:</strong> Edge medical IoT devices broadcast unauthenticated telemetry without verifiable hardware identity or anomaly defense.
              </span>
            </li>
          </ul>
        </div>

        {/* Proposed Solution */}
        <div className="p-5 rounded-xl bg-slate-900/80 border border-emerald-500/30 space-y-3">
          <div className="flex items-center gap-2 text-emerald-400 font-bold font-mono text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            PROPOSED SOLUTION
          </div>
          <h3 className="text-sm font-bold text-slate-100 font-sans">
            Decentralized Identity & Dynamic Attribute-Based Control
          </h3>
          <ul className="space-y-2 text-xs text-slate-300 font-sans leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold font-mono">✓</span>
              <span>
                <strong>Self-Sovereign Identity (W3C DIDs):</strong> Patients, doctors, administrators, and IoMT hardware own cryptographic decentralized identifiers decoupled from central authorities.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold font-mono">✓</span>
              <span>
                <strong>Dynamic Patient Consent (ABAC + RBAC):</strong> Fine-grained, time-bounded permissions where patients explicitly approve or reject individual record scopes.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold font-mono">✓</span>
              <span>
                <strong>Multi-Hospital Consortium Federation:</strong> CityCare, Sanjivani, Apollo, and Rural Clinics share verifiable data through an immutable PBFT consortium blockchain.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold font-mono">✓</span>
              <span>
                <strong>IoMT Telemetry & Break-Glass Emergency:</strong> Real-time biometric anomaly detection paired with emergency override capability with permanent audit tracking.
              </span>
            </li>
          </ul>
        </div>
      </div>

      {/* Key Innovations & Novel Contributions */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-slate-100 font-sans flex items-center gap-2">
          <Award className="w-4 h-4 text-emerald-400" /> Academic Novelty & Technical Contributions
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 text-xs font-mono">
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-2 text-cyan-400 font-bold font-sans">
              <Fingerprint className="w-4 h-4" /> 1. W3C DIDs for IoMT Edge Nodes
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Medical devices (CGMs, pulse oximeters, ECG monitors) possess independent cryptographic DIDs, ensuring every biometric packet is signed at the edge before storage.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-2 text-emerald-400 font-bold font-sans">
              <ShieldCheck className="w-4 h-4" /> 2. Fine-Grained Record Restricting
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Enforces record-level authorization. Doctors authorized to review blood pressure or diagnosis records are strictly denied access to sensitive genetic markers.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-2 text-indigo-400 font-bold font-sans">
              <Building2 className="w-4 h-4" /> 3. Cross-Institutional Trust Mesh
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Multi-hospital consortium ledger verifies credential validity without passing private health records to untrusted central clearinghouses.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-bold font-sans">
              <Activity className="w-4 h-4" /> 4. Real-Time Telemetry Anomalies
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Edge telemetry processor flags abnormal vitals (tachycardia, systolic spikes, hypoxia) and anchors security events onto the blockchain.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-2 text-rose-400 font-bold font-sans">
              <Flame className="w-4 h-4" /> 5. Accountable Break-Glass Protocol
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Emergency override mechanism for trauma care that temporarily bypasses consent while locking an immutable cryptographic audit record.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-2 text-emerald-400 font-bold font-sans">
              <Layers className="w-4 h-4" /> 6. Zero Trust Verification Pipeline
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Continuous validation of identity validity, token expiration, institutional trust score, and cryptographic signature before every transaction.
            </p>
          </div>
        </div>
      </div>

      {/* System Architecture Diagram / Flow */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-slate-100 font-sans flex items-center gap-2">
          <GitBranch className="w-4 h-4 text-cyan-400" /> High-Level System Architecture & Layering
        </h3>

        <div className="space-y-3 font-mono text-xs">
          {/* Layer 1 */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <span className="text-emerald-400 font-bold block text-[11px]">LAYER 1: PRESENTATION & IDENTITY CUSTODY</span>
              <span className="text-slate-300 font-sans text-xs">
                Role-adaptive Patient, Doctor, and Administrator Dashboards; Client-side Ed25519 Key Management.
              </span>
            </div>
            <Badge variant="emerald">React 19 + TypeScript + Tailwind</Badge>
          </div>

          {/* Layer 2 */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <span className="text-cyan-400 font-bold block text-[11px]">LAYER 2: ACCESS CONTROL & CONSENT ENGINE</span>
              <span className="text-slate-300 font-sans text-xs">
                Dynamic RBAC + ABAC Authorization Gate, Time-Lock Evaluator, Break-Glass Emergency Controller.
              </span>
            </div>
            <Badge variant="cyan">Policy Engine (ABAC + RBAC)</Badge>
          </div>

          {/* Layer 3 */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <span className="text-indigo-400 font-bold block text-[11px]">LAYER 3: EDGE IOMT TELEMETRY MESH</span>
              <span className="text-slate-300 font-sans text-xs">
                Biometric Telemetry Streamers (BP, CGM, SpO2, ECG) with Live Statistical Anomaly Interceptors.
              </span>
            </div>
            <Badge variant="indigo">W3C DID IoMT Gateway</Badge>
          </div>

          {/* Layer 4 */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <span className="text-amber-400 font-bold block text-[11px]">LAYER 4: IMMUTABLE CONSORTIUM LEDGER</span>
              <span className="text-slate-300 font-sans text-xs">
                Cryptographic Block Sequence, SHA-256 Hash Pointers, Merkle Root Verification, PBFT Peer Verification.
              </span>
            </div>
            <Badge variant="amber">Hyperledger / PBFT Ledger Simulation</Badge>
          </div>
        </div>
      </div>

      {/* Tech Stack & Standards Compliance */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3 font-mono text-xs">
        <h3 className="text-sm font-bold text-slate-100 font-sans flex items-center gap-2">
          <Cpu className="w-4 h-4 text-emerald-400" /> Standards & Technology Stack
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-[11px]">
          <div className="p-3 rounded bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block">IDENTITY STANDARD</span>
            <span className="text-emerald-300 font-bold">W3C DID v1.0</span>
          </div>
          <div className="p-3 rounded bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block">CRYPTOGRAPHIC SUITE</span>
            <span className="text-cyan-300 font-bold">Ed25519 & SHA-256</span>
          </div>
          <div className="p-3 rounded bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block">ACCESS FRAMEWORK</span>
            <span className="text-indigo-300 font-bold">Dynamic ABAC + RBAC</span>
          </div>
          <div className="p-3 rounded bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block">CONSENSUS MODEL</span>
            <span className="text-amber-300 font-bold">Federated PBFT</span>
          </div>
        </div>
      </div>
    </div>
  );
};
