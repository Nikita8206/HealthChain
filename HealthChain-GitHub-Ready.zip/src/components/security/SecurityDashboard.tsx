import React, { useState, useEffect } from 'react';
import { SecurityEvent } from '../../types';
import { storageService, subscribeToStorage } from '../../services/storageService';
import { Badge } from '../common/Badge';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Radio,
  Lock,
  CheckCircle2,
  FileWarning,
  Activity,
  Terminal,
} from 'lucide-react';

export const SecurityDashboard: React.FC = () => {
  const [events, setEvents] = useState<SecurityEvent[]>([]);

  useEffect(() => {
    const update = () => {
      setEvents(storageService.getSecurityEvents());
    };
    update();
    return subscribeToStorage(update);
  }, []);

  const unauthorizedAttempts = events.filter((e) => e.type === 'UNAUTHORIZED_ACCESS');
  const ehrDenied = events.filter((e) => e.type === 'EHR_ACCESS_DENIED');
  const iomtAnomalies = events.filter((e) => e.type === 'IOMT_ANOMALY');
  const emergencyEvents = events.filter((e) => e.type === 'EMERGENCY_ACCESS');
  const criticalCount = events.filter((e) => e.severity === 'CRITICAL').length;

  return (
    <div id="security-dashboard-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-rose-400">
              ZERO TRUST CYBERSECURITY
            </span>
            <Badge variant={criticalCount > 0 ? 'rose' : 'emerald'} dot>
              {criticalCount > 0 ? 'High Threat Vigilance' : 'Normal Defense Posture'}
            </Badge>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">
            Cybersecurity Incident Center & Threat Detection
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Real-time audit telemetry monitoring unauthorized EHR inspection attempts, anomalous IoMT hardware signals, consent revocations, and break-glass emergency triggers across all federated hospital nodes.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-right font-mono text-xs">
            <span className="text-slate-500 block text-[10px]">TOTAL THREAT AUDITS</span>
            <span className="text-rose-400 font-bold text-lg">{events.length}</span>
          </div>
        </div>
      </div>

      {/* Security Metrics Cards (4 key tiles) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>EHR DENIED ATTEMPTS</span>
            <Lock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-amber-400 mt-2">
            {ehrDenied.length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">
            Zero-Trust access blockades
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>IOMT ANOMALIES</span>
            <Radio className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-cyan-400 mt-2">
            {iomtAnomalies.length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">
            Hardware biometric threshold trips
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>EMERGENCY OVERRIDES</span>
            <Flame className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-rose-400 mt-2">
            {emergencyEvents.length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">
            Break-Glass protocols invoked
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>UNAUTHORIZED ACCESS</span>
            <ShieldAlert className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-3xl font-bold font-mono text-rose-500 mt-2">
            {unauthorizedAttempts.length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">
            Intercepted unverified identities
          </div>
        </div>
      </div>

      {/* Live Incident Log Table */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-rose-400" /> Live Threat Incident Log
            </h3>
            <p className="text-[11px] text-slate-400">
              Correlated audit entries logged to both the local SIEM engine and consortium ledger
            </p>
          </div>
          <Badge variant="rose">{events.length} Incidents Documented</Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Severity</th>
                <th className="py-2.5 px-3">Event Type</th>
                <th className="py-2.5 px-3">Actor DID / Node</th>
                <th className="py-2.5 px-3">Description</th>
                <th className="py-2.5 px-3">Automated Defense Action</th>
                <th className="py-2.5 px-3 text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {events.map((evt) => (
                <tr key={evt.id} id={`sec-event-${evt.id}`} className="hover:bg-slate-800/30">
                  <td className="py-3 px-3">
                    <Badge
                      variant={
                        evt.severity === 'CRITICAL'
                          ? 'rose'
                          : evt.severity === 'HIGH'
                          ? 'rose'
                          : evt.severity === 'MEDIUM'
                          ? 'amber'
                          : 'cyan'
                      }
                    >
                      {evt.severity}
                    </Badge>
                  </td>
                  <td className="py-3 px-3 font-semibold text-slate-200">{evt.type}</td>
                  <td className="py-3 px-3 text-cyan-300 text-[11px]">{evt.actorDid}</td>
                  <td className="py-3 px-3 text-slate-300 font-sans max-w-xs">{evt.description}</td>
                  <td className="py-3 px-3 text-emerald-400 font-semibold">
                    ✓ {evt.actionTaken}
                  </td>
                  <td className="py-3 px-3 text-slate-500 text-[10px] text-right">
                    {new Date(evt.timestamp).toLocaleTimeString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Security Architecture & Defense Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
          <h4 className="text-xs font-bold text-slate-200 font-sans flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Zero Trust Policy Engine
          </h4>
          <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
            Never trust, always verify. Every request undergoes cryptographic DID verification, attribute-based access validation, and explicit patient consent checking before any payload decryption occurs.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
          <h4 className="text-xs font-bold text-slate-200 font-sans flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-cyan-400" /> IoMT Telemetry Anomaly Guard
          </h4>
          <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
            Biometric telemetry streams are evaluated against physiological ranges. Extreme readings trigger automated clinical alerts and immutable tamper-proof logs on the blockchain.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
          <h4 className="text-xs font-bold text-slate-200 font-sans flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-rose-400" /> Break-Glass Accountability
          </h4>
          <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
            Emergency overrides grant temporary, time-locked access windows. The physician must provide a legally binding justification that is permanently audited.
          </p>
        </div>
      </div>
    </div>
  );
};
